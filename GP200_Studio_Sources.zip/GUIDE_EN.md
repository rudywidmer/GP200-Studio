# GP-200 Studio — User Guide

## What is it?

GP-200 Studio generates presets (`.prst` files) for your **Valeton GP-200**
from a simple text description. You describe the sound you want, an AI creates
the preset, and you just copy it onto your SD card.

Example descriptions:
- *"Crystal clean with chorus and spring reverb"*
- *"Warm bluesy crunch, Stevie Ray Vaughan style"*
- *"Modern metal, saturated gain, tight gate, slapback delay"*
- *"Pink Floyd lead with long delay and wide reverb"*


## Requirements

- **Python 3.10+** installed (check *"Add python.exe to PATH"* during install)
- **Tkinter** included (default on Windows if you check *"tcl/tk and IDLE"*
  during Python installation)
- **An API key** for at least one of the supported AI providers (see below)

Nothing else to install: the application uses only Python's standard library.


## Installation

1. Extract the zip contents into a folder of your choice
2. Copy `config.example.json` to `config.json`
3. Open `config.json` with a text editor and paste your API key
4. Double-click `GP200_Studio.bat` (or run `python gp200_studio.py`)

On first launch, the application will ask you to choose your language and
enter your API keys through a graphical dialog.


## Getting an API key

The application needs an API key to communicate with an AI service.
**This key is personal, and API calls are generally at your own cost.**
Here are the four options:

### Google Gemini — recommended to get started
- **Cost**: free (limited quota, but enough for normal use)
- **Credit card**: not required
- **Link**: https://aistudio.google.com/app/apikey
- **Steps**: sign in with your Google account, click *"Create API Key"*,
  copy the generated key

### Anthropic Claude
- **Cost**: pay-per-use (~$0.003 to $0.015 per preset depending on model)
- **Credit card**: required (prepaid credits, minimum ~$5)
- **Link**: https://console.anthropic.com/settings/keys
- **Steps**: create an account, add credits, generate an API key

### OpenAI (ChatGPT)
- **Cost**: pay-per-use (~$0.002 to $0.01 per preset depending on model)
- **Credit card**: required (prepaid credits)
- **Link**: https://platform.openai.com/api-keys
- **Steps**: create an account, add credits, generate an API key

### Perplexity
- **Cost**: pay-per-use (web search included in the price)
- **Credit card**: required
- **Link**: https://www.perplexity.ai/settings/api
- **Steps**: create an account, add credits, generate an API key

**Security**: your API key is stored locally in your `config.json`,
encrypted on Windows via DPAPI. It is never sent anywhere other than to
the AI provider you selected.


## The interface

```
+-----------------------------------------------------------------------+
|  GP-200 STUDIO         New / Refine            Language  Keys  Folder  |
+-------------------+---------------------------------------------------+
|  OPTIONS          |  DESCRIBE THE SOUND YOU WANT                      |
|   provider        |  [ text area ]                                    |
|   model           |  EXAMPLES                                         |
|   guitar pickup   |  SONG STRUCTURE                                   |
|   web search      |                                                   |
|                   |  SIGNAL CHAIN      <name of displayed preset>     |
|  API USAGE        |  [PRE][WAH][DST][AMP][NR][CAB][EQ][MOD][DLY]...   |
|                   |  +-----------------------------------------+     |
|  GENERATED        |  | AMP  Mess2C+ 2             module 4/11  |     |
|  PRESETS          |  | GAIN 65   PRESENCE 70   VOLUME 75  ...  |     |
|   > variant A     |  +-----------------------------------------+     |
|     variant B     |                                                   |
|     variant C     |  Result | Log                                     |
|     ...           |  [ detailed report ]                              |
+-------------------+---------------------------------------------------+
|  o  status                    Setlist | Live |  GENERATE PRESETS      |
+-----------------------------------------------------------------------+
```

The interface adapts to your screen resolution: everything is larger on a big
display and tighter on a laptop. The window opens at 90% of the screen, centred.

### The signal chain

All 11 modules of the preset are shown **on a single row**, in the actual order
of the chain, linked by a cord like a pedalboard. The colour tells you where you
are in the chain:

| Colour | Modules | Role |
|---|---|---|
| **Blue** | `PRE`, `DST`, `AMP` | makes the sound |
| **Green** | `NR`, `CAB`, `EQ` | shapes it |
| **Magenta** | `WAH`, `MOD`, `DLY`, `RVB`, `VOL` | colours it |

A dashed module with a `+` is **bypassed**: on the GP-200 a slot is never empty,
it is simply switched off.

During generation, **the cord lights up module by module** while a bright dot
travels along it. That is the progress indicator — it tells you how far the
preset writing has got.

### The module inspector

**Click a module** in the chain: all of its settings appear just below, with a
gauge on values between 0 and 100.

The chain cards are deliberately narrow and show a single parameter, with a `+5`
marker telling you how many more are waiting. An amp often exposes six or more.
**The cards tell you the signal path, the inspector tells you the values.**

Values with no known scale (a delay time in milliseconds, a cutoff frequency in
Hz) get no gauge — a wrong gauge would be worse than none.

This panel is read-only: it never modifies your preset.

### Browsing generated presets

A generation writes 3 variants per section, so up to 9 files at once. The left
column lists them all, under **GENERATED PRESETS**.

Click one: the chain is rebuilt, the inspector follows, and the file path appears
at the bottom of the window. The displayed preset's name sits next to the
*Signal chain* heading — you always know what you are looking at.

The three variants of a section share the same edge colour, so blocks like
`Rhythm A/B/C` and `Clean A/B/C` are instantly recognisable.

The list is also filled after a refine and when loading a `.prst`.


## Usage

### Generate presets ("New" mode)

1. Select your **AI provider** and **model** from the dropdown menus
2. Type your description in the text area (or pick an example from the list)
3. Toggle **web search** on or off (helps the AI identify the real gear
   used by an artist, but uses more tokens)
4. Choose the **structure**:
   - **Auto detection**: the AI decides how many presets to create and
     how to organize them (3, 6 or 9 presets)
   - **Force roles**: check the roles you want
     (`clean`, `crunch`, `disto`, `lead`) — 3 presets per role
5. Click **Generate**
6. The `.prst` files are written to the output folder (by default
   `Documents\GP200_Presets`) and appear in the left-hand list so you can review
   them one by one

### Refine a preset ("Refine" mode)

1. Switch to **Refine** mode using the selector at the top
2. Load an existing `.prst` file (a preset you want to modify). **Its chain is
   displayed immediately**, before any AI call: you can already click through the
   modules to inspect their current settings.
3. Describe the changes you want in plain text
   (*"more gain"*, *"remove the delay"*, *"switch the amp to a Fender"*)
4. Click **Refine**
5. The application shows the actual changes, compared against the original preset

The original preset is never modified: a new version is written into a timestamped
subfolder.

### Optimise for live

In Refine mode, the **Live ready** button adapts a preset made at home for
high-volume stage use: reduced gain, reduced reverb/delay mix, a high cut on the
cab to fight fizz, and a slight midrange boost. Creative EQ and artistic intent
are preserved.

### Harmonise a setlist

Still in Refine mode, **Harmonise setlist** lets you load 10 or 15 presets and
levels their volumes against each other, so there is no jump between songs. No
API call, instant: only the volume byte changes, and the harmonised files go into
a new folder.

### Change language

Use the language dropdown at the top of the window. The change is instant
and persists across sessions. Available languages: French, English, Spanish.
Already-generated presets stay in the list.

### Edit API keys

Click the **API Keys** button to open the key input dialog.
You can configure multiple keys and switch providers on the fly.


## Copying presets to the GP-200

1. Open the output folder (click the **Output folder** button)
2. Copy the `.prst` files onto your GP-200's SD card
   (`PRESET` folder at the root of the card)
3. Insert the card into the GP-200 and import the presets from the menu


## Usage tracking

If you're using a paid provider (Claude, OpenAI, Perplexity), the application
shows an estimate of each generation's cost and a running total. This tracking
is a local estimate based on token count — check your actual balance directly
on the provider's website.

You can set a spending cap in `config.json` (`budget_usd`) to give yourself
a visual limit.


## Common issues

| Symptom | Solution |
|---------|----------|
| *"Invalid API key"* | Check the key (no leading/trailing spaces) and the selected provider |
| *"Unknown model"* | The AI hallucinated a name — rephrase your description; auto-correction handles most cases |
| `.prst` files won't import | Make sure they're in the `PRESET` folder on the SD card |
| App won't start | Check Python is in PATH (`python --version`) and Tkinter works (`python -c "import tkinter"`) |
| Network error / timeout | Check your internet connection and that the AI provider is reachable |
| The chain wraps onto several rows | The window is too narrow to line up all 11 modules. Widen it, or maximise it. |
| The interface looks too large or too small | It sizes itself from your screen resolution at startup. Restart the application after changing resolution or Windows scaling. |

> **Note**: the interface is dark-mode only. The light/dark toggle from earlier
> versions has been removed; if your `config.json` still contains a `"theme"`
> key, it is simply ignored.
