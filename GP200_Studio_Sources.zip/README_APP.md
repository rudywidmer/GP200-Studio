# GP-200 Studio — installation

Appli Windows : tu decris un son, elle interroge une IA (Gemini, Claude, OpenAI
ou Perplexity), valide les specs contre les tables extraites du firmware, et ecrit
3 a 9 fichiers `.prst` prets a importer.

L'interface affiche la chaine de signal complete du preset, permet de cliquer
chaque module pour voir tous ses reglages, et de naviguer entre les presets
generes. Voir **Interface** plus bas.

## Pourquoi pas Google Colab
Colab tourne sur une **VM Linux dans le navigateur**. PyInstaller ne cross-compile
pas : un `.exe` Windows doit etre compile **sur** Windows. Colab reste possible
pour un usage notebook, mais ne produira jamais d'appli Windows.

---

## Option A — sans compiler (le plus rapide)

1. Installer Python 3.9+ : https://www.python.org/downloads/
   **Cocher « Add python.exe to PATH »** pendant l'installation.
2. Copier `config.example.json` en **`config.json`** et y mettre la cle API
   (https://console.anthropic.com/settings/keys).
3. Double-cliquer sur **`GP200_Studio.bat`**.

Aucune dependance a installer : l'appli n'utilise que la bibliotheque standard
(Tkinter + urllib).

## Option B — fabriquer le .exe

1. Faire l'etape 1 ci-dessus.
2. Double-cliquer sur **`build_exe.bat`** (cree un venv, installe PyInstaller,
   compile). Quelques minutes la premiere fois.
3. Resultat : **`dist\GP200_Studio.exe`** (~15 Mo, autonome).
4. Mettre la cle dans **`dist\config.json`**.

`GP200_Studio.exe` et `config.json` doivent rester **dans le meme dossier**.
Les tables et le template sont embarques dans l'exe.

### Arborescence attendue AVANT compilation
Tout au meme niveau, **sans sous-dossier** `GP200_Studio\` :
```
mon_dossier\
  build_exe.bat
  GP200_Studio.bat
  gp200_studio.py
  gp200_theme.py         <- indispensable (systeme de design)
  gp200_ui.py            <- indispensable (composants graphiques)
  gp200_agent.py
  gp200lib.py
  gp200_setlist.py
  gp200_i18n.py
  gp200_secrets.py
  template.prst          <- indispensable
  config.example.json
  data\                  <- indispensable, 15 fichiers .json
```
`build_exe.bat` verifie tout cela avant de compiler et liste ce qui manque.

---

## La cle API

L'appli sait parler a **quatre fournisseurs**. Choisis dans l'interface, ou via
`"provider"` dans `config.json`.

| Fournisseur | Cout | Ou prendre une cle |
|---|---|---|
| **Google Gemini** (defaut) | **offre gratuite, sans carte bancaire** | https://aistudio.google.com/app/apikey |
| Anthropic Claude | payant a l'usage, ~0,03 € par generation | https://console.anthropic.com/settings/keys |
| OpenAI | payant a l'usage | https://platform.openai.com/api-keys |
| Perplexity | payant a l'usage (recherche web incluse) | https://www.perplexity.ai/settings/api |

Seul Anthropic remonte un suivi de cout detaille : c'est le seul provider pour
lequel l'appli affiche une estimation de depense.

> L'API Anthropic est facturee a l'usage et **n'a rien a voir avec un abonnement
> Claude Pro/Max** : l'abonnement ne donne aucun credit API. Un solde vide
> renvoie `HTTP 400 : credit balance is too low`.

```json
{
  "provider": "gemini",

  "api_key_gemini": "AIza...",
  "api_key_anthropic": "",

  "model": "",
  "web_search": true,
  "output_dir": "",
  "max_retries": 2
}
```

| champ | role |
|---|---|
| `provider` | `"gemini"` ou `"anthropic"` |
| `api_key_gemini` / `api_key_anthropic` | les cles. Les deux peuvent coexister : tu bascules dans l'interface sans rien recoller. |
| `model` | vide = le defaut du fournisseur. Le bouton **Actualiser** interroge l'API pour la liste reelle. |
| `web_search` | laisse le modele chercher le vrai rig de la chanson (Google Search chez Gemini, web_search chez Anthropic). |
| `max_tokens` | plafond de sortie (defaut 16000). Trop bas = JSON coupe et appel perdu. |
| `budget_usd` | ton budget, pour l'affichage du reste. 0 = desactive. |
| `output_dir` | vide = `Documents\GP200_Presets`. Chaque run cree son propre sous-dossier horodate. |
| `max_retries` | tentatives d'auto-correction si le modele invente un nom |

Ordre de priorite des cles : variable d'environnement (`GEMINI_API_KEY` /
`ANTHROPIC_API_KEY`) > `config.json` a cote de l'exe > `%APPDATA%\GP200Studio\config.json`.

⚠️ Une cle donne acces a ton compte. Ne la mets pas dans l'exe, ne la partage
pas, revoque-la depuis la console si elle fuite. Le `.gitignore` couvre `config.json`.

### Ce que ca coute vraiment (Anthropic)

Tarifs officiels : https://docs.claude.com/en/docs/about-claude/pricing

| Poste | Prix |
|---|---|
| Sonnet 5 | **2 $ / 10 $** par million de tokens (entree/sortie) — tarif d'introduction jusqu'au **31/08/2026**, puis 3 $ / 15 $ |
| Opus 4.8 | 5 $ / 25 $ |
| Haiku 4.5 | 1 $ / 5 $ |
| Recherche web | **10 $ pour 1 000 recherches** (0,01 $ chacune) **+ les tokens des resultats** |
| Lecture de cache | 10 % du prix d'entree |

**Le piege** : les resultats de recherche web sont factures comme tokens
d'entree, et ils sont **renvoyes a chaque tour suivant**. Une generation avec
recherche web + une tentative d'auto-correction tourne autour de
**0,10 a 0,25 $**, pas 0,03 $. Sans recherche web : environ **0,03 a 0,06 $**.

**Deux optimisations sont actives :**
- Le prompt systeme (~7 200 tokens de catalogue, identique a chaque appel) est
  **mis en cache**. Le cache vit 5 minutes : si tu enchaines les generations,
  les suivantes ne paient que 10 % dessus.
- `max_searches` limite les recherches web a **3** par generation.

L'appli affiche le **cout reel de chaque appel**, le **cumul de la session** et
la **depense cumulee entre les sessions** (fichier `spend.json`). Renseigne
`budget_usd` dans `config.json` pour voir ce qu'il te reste :

```
Anthropic Claude · cle OK  |  budget $6.00 · depense $0.412 · reste $5.59
```

> ⚠️ C'est une **estimation locale**, calculee depuis l'objet `usage` renvoye par
> l'API et les tarifs codes dans `PRICES`. Elle ignore les appels faits ailleurs
> et devient fausse si les tarifs changent.
> **La console fait foi : https://console.anthropic.com/settings/usage**

### Il n'existe pas de "tokens restants"
L'API Anthropic se facture en **dollars de credit prepaye**, pas en quota de
tokens. Aucun endpoint public ne donne le solde avec une cle standard (la Rate
Limits API d'avril 2026 exige une cle **Admin**). Ce que l'appli peut montrer :

| Source | Ce que ca dit |
|---|---|
| En-tetes `anthropic-ratelimit-*` (sur chaque reponse) | requetes et tokens restants **pour la minute en cours** |
| `budget_usd` moins `spend.json` | ce qu'il reste de ton budget (estimation) |
| `HTTP 429` avec un message "credit" | **solde epuise** : attendre n'y changera rien, il faut recharger |

**Pour depenser moins** : passe le modele sur `claude-haiku-4-5-20251001` (deux fois
moins cher que Sonnet). La validation stricte contre les tables du firmware rattrape
les erreurs quel que soit le modele — un modele moins cher ne peut pas produire un
preset invalide, juste des choix musicaux moins fins.

> **Ne coupe PAS la recherche web pour economiser.** Test reel sur *Master of
> Puppets* : **avec** recherche, le modele identifie le Mesa Mark IIC+ slave dans
> un JCM800, l'EQ en V et l'absence de reverb sur les pistes rythmiques. **Sans**
> recherche, il repond "likely JCM800", rate completement le Mesa — qui EST le son
> du morceau — et ajoute de la reverb partout. L'economie est de ~0,15 $ ; le
> preset devient faux. Ne la coupe que si TU connais le rig et le decris toi-meme
> dans la demande.

### A savoir sur l'offre gratuite Gemini
- Pas de carte bancaire, pas d'expiration, sur la famille **Flash / Flash-Lite**.
- Quotas par **projet** (pas par cle) : creer plusieurs cles n'augmente rien.
  Un depassement renvoie `HTTP 429`. Les limites reelles s'affichent dans AI Studio.
- **Google peut utiliser tes requetes pour ameliorer ses modeles.** Ici on
  n'envoie que des descriptions de sons, donc sans consequence.
- **Activer la facturation sur un projet supprime son offre gratuite.** Si tu
  veux les deux, utilise deux projets Google Cloud distincts.
- Les noms de modeles bougent vite (Google a retire `gemini-2.0-flash` en mars
  2026). D'ou le bouton **Actualiser**, qui demande la liste au lieu de la deviner.

## Structure du morceau

L'appli ne produit plus systematiquement 3 presets : elle determine d'abord
**combien de sons DIFFERENTS le morceau demande**, puis sort 3 variantes par son.

| Morceau | Sections | Fichiers |
|---|---|---|
| Un seul son du debut a la fin | 1 | **3** |
| Couplet clair + refrain sature | 2 | **6** |
| Clair + sature + solo lead | 3 | **9** |

- **Detection automatique** (defaut) : le modele decide depuis sa recherche.
  Regle dure du prompt : *ne jamais inventer de section*. Beaucoup de morceaux
  metal se jouent integralement avec un seul son rythmique, et une seule section
  est alors la bonne reponse.
- **Forcage manuel** : decoche la detection auto et coche les roles voulus parmi
  `clean`, `crunch`, `disto`, `lead`. Le modele produit exactement ces sections,
  dans cet ordre.

Des qu'il y a plusieurs sections, chacune a son sous-dossier :
```
2026-07-16_204058_Nothing_Else_Matters/
  1_Intro/      NEM_Cln_Fid_A.prst   NEM_Cln_Alt_B.prst   NEM_Cln_Prat_C.prst
  2_Rythmique/  NEM_Rhy_Fid_A.prst   ...
  3_Solo/       NEM_Solo_Fid_A.prst  ...
```

**Un seul appel API pour toutes les sections** : le cache du prompt et la
recherche web sont mutualises. 9 presets coutent a peine plus cher que 3.

**Garde-fous specifiques :** 4 sections maximum ; exactement 3 variantes par
section ; roles limites a la liste ; noms de presets distincts d'une section a
l'autre (16 caracteres, c'est court) ; et la divergence (AMP, CAB) se verifie
**dans** une section — deux sections ont le droit de partager un ampli, une
rythmique et un solo sur le meme Mesa etant parfaitement legitimes.

## Affiner un preset existant

Coche **« Affiner un preset existant »**, charge un `.prst`, et decris en clair
ce que tu veux changer :

> *"il y a trop de reverb, remplace le chorus par un flanger, ajoute un delay"*

L'appli decode le preset, l'envoie au modele avec ta demande, et ecrit une
version `_v2.prst` dans un sous-dossier horodate. Le preset d'origine n'est
jamais touche.

**Le diff affiche est calcule sur les fichiers decodes** (avant vs apres), pas
recopie de ce que le modele pretend avoir fait :

```
CHANGEMENTS REELS (calcules sur les fichiers, pas declares par le modele)
  * MOD : C-Chorus -> Jet
  * DLY : Pure -> Digital Delay S
  * RVB / Mix : 12 -> 4
```

Si le diff est vide, l'appli te le dit : la demande n'a pas ete comprise.

Regle du prompt : **ne changer QUE ce qui est demande**. Si tu dis "trop de
reverb", l'ampli ne bouge pas. Et comme un slot ne peut contenir qu'un seul
effet, demander un flanger quand un chorus occupe deja le slot MOD produit un
avertissement explicite plutot qu'un ecrasement silencieux.

## Optimiser pour le concert

En mode Affiner, le bouton **Optimiser pour concert** adapte un preset fait a la
maison pour le jeu a fort volume : gain reduit, mix reverb/delay reduits, coupe-
haut sur le baffle contre la fizz, leger boost de mediums. L'EQ creatif et
l'intention artistique sont preserves. Le preset d'origine n'est pas touche.

## Harmoniser une setlist

Toujours en mode Affiner, **Harmoniser setlist** charge 10 ou 15 presets et
egalise leurs volumes entre eux, pour eviter les sauts de niveau d'un morceau a
l'autre. **Aucun appel API**, instantane : seul l'octet `patch_vol` change, le
checksum est recalcule, et les fichiers harmonises partent dans un dossier
horodate.

## Usage API

Panneau permanent en haut de la fenetre, toujours visible :

```
┌─ Usage API ────────────────────────────────────────────────┐
│ Budget $6.00   depense $0.31   reste $5.69 (95%)  2 appels │
│ session $0.0605   |   quota minute : requests 9998/10000   │
└────────────────────────────────────────────────────────────┘
```

La barre passe au orange sous 25 % du budget, au rouge sous 10 %. Le bouton
**Remettre a zero** efface le compteur local (`spend.json`) sans toucher a ton
solde reel.

## Interface

L'interface est en Tkinter pur, **sans aucune dependance graphique tierce**
(ni `sv-ttk`, ni `ttkbootstrap`, ni PIL). Elle repose sur deux fichiers :
`gp200_theme.py` (palette, theme ttk, mise a l'echelle) et `gp200_ui.py`
(composants dessines au Canvas). Aucun des deux n'importe quoi que ce soit du
moteur : ils ne savent pas ce qu'est un `.prst`.

### La chaine de signal

Les 11 modules du preset s'affichent **sur une seule ligne**, dans l'ordre reel
de la chaine, relies par un cordon comme sur un pedalier. La couleur dit ou l'on
se trouve dans la chaine :

| Couleur | Modules | Role |
|---|---|---|
| Bleu | `PRE`, `DST`, `AMP` | ce qui fabrique le son |
| Vert | `NR`, `CAB`, `EQ` | ce qui le met en forme |
| Mauve | `WAH`, `MOD`, `DLY`, `RVB`, `VOL` | ce qui le colore |

Un module en pointille avec un `+` est **bypasse** : sur le GP-200 un slot n'est
jamais vide, il est desactive.

Pendant une generation, **le cordon s'allume module par module** : c'est
l'indicateur de progression, il n'y a plus de barre indeterminee.

### Inspecteur de module

Un clic sur un module affiche **tous** ses reglages sous la chaine, avec une
jauge sur les valeurs en 0-100. Les valeurs sans echelle connue (temps de delay
en ms, frequence de coupure en Hz) n'ont volontairement pas de jauge.

Les cartes de la chaine sont etroites et n'affichent qu'un parametre, avec un
`+5` indiquant combien d'autres attendent. Les cartes disent le **trajet**,
l'inspecteur dit les **valeurs**. Affichage en lecture seule.

### Navigation dans les presets generes

Une generation ecrit jusqu'a 9 fichiers. La colonne de gauche les liste tous ;
un clic recompose la chaine correspondante et affiche le chemin du fichier. Les
trois variantes d'une meme section partagent la couleur de leur liseré. La liste
se remplit aussi apres un affinage et au chargement d'un `.prst`.

### Mise a l'echelle

Un facteur global est deduit de la resolution de l'ecran (0,85 a 1,30) et
applique aux cartes, espacements et polices. La fenetre s'ouvre a 90 % de
l'ecran. Le rack calcule ensuite sa propre echelle pour tenir sur une ligne :
verifie de 1366x768 a 2560x1440. En dessous d'environ 600 px de large, repli sur
plusieurs rangs avec defilement.

### Mode sombre uniquement

Le bouton de bascule clair/sombre a ete retire. La cle `"theme"` d'un ancien
`config.json` est ignoree sans erreur — aucune migration necessaire.

### Maquette autonome

```
python design_preview.py
```

Ouvre l'interface avec des donnees fictives : ni cle API, ni reseau, ni ecriture
de fichier. Sert a iterer sur le design sans lancer l'application complete.

## Comment ca marche

```
description  ->  prompt systeme (~7 200 tokens : regles + catalogue compact
                 + decodeur de nommage Valeton + patch Petrucci de reference)
             ->  API Gemini ou Claude (+ recherche web optionnelle)
             ->  JSON : 3 variantes A/B/C
             ->  VALIDATION contre les tables firmware
                   nom inexistant ? -> renvoye au modele avec des suggestions
                                       (jusqu'a max_retries)
             ->  gp200lib.encode_prst : place les floats via les `slot` reels
             ->  3 x .prst + 3 x .json  +  relecture/checksum
```

**Deux garanties structurelles :**
- Le modele ne voit **jamais** les `slot`. C'est `gp200lib` qui place les floats.
  Une hallucination sur un slot est donc *impossible*.
- Un nom de modele invente **ne peut pas** produire de fichier : la validation
  echoue et renvoie l'erreur au modele avec les noms proches.

## Limite a connaitre

**Aucun preset n'a jamais ete importe dans un GP-200 physique.** Le format est
verifie par round-trip sur un patch reel, mais le comportement de l'appareil a
l'import reste a confirmer. Voir §5 du cahier des charges.

En revanche le **catalogue** n'est plus une supposition : depuis le 17/07/2026 il
est confronte a `algorithm.xml`, le fichier dont l'editeur officiel Valeton se
sert pour afficher ses menus (305 algorithmes, noms + parametres + catalogues).
Resultat : 0 modele invente, 0 slot faux, 0 borne fausse. Voir `CHANGELOG.md`.

> **Version du firmware.** Ces tables decrivent le **V1.8.0**. Valeton apparie
> strictement firmware et editeur (« Firmware V1.8.0 — Compatible Software
> v1.8.0 ») et la v1.8.0 ajoute des effets. Sur une unite en 1.6.3 ou 1.7.0 le
> catalogue est different. Verifier la version avant toute generation, et
> relancer `xml_diff.py` apres chaque mise a jour.

## Depannage

| Symptome | Cause |
|---|---|
| `Unable to find ...\data when adding binary and data files` | le dossier `data\` n'est pas a cote de `build_exe.bat`. Extraire **tout** le zip au meme niveau, sans sous-dossier. |
| `Running PyInstaller as admin` | lancer depuis un terminal **normal**, pas administrateur |
| `Python introuvable` | PATH — reinstaller en cochant « Add python.exe to PATH » |
| `API HTTP 400 : credit balance is too low` | Anthropic : solde API vide. Acheter des credits, ou passer a `"provider": "gemini"`. |
| `API HTTP 401` / `403` | cle invalide, revoquee, ou API non activee |
| `API HTTP 400 ... model` | nom de modele errone : clique **Actualiser** |
| `API HTTP 429` | quota atteint. Gemini gratuit = quelques requetes/minute : attendre un peu. |
| `reponse illisible` / `REPONSE TRONQUEE` | le modele a depasse `max_tokens` et son JSON a ete coupe. Augmenter `max_tokens` dans `config.json`. |
| `Reseau` | proxy d'entreprise : definir `HTTPS_PROXY` |
| Echec apres N tentatives | demande trop vague, ou aucun equivalent au catalogue |
| `ModuleNotFoundError: gp200_theme` / `gp200_ui` | les deux fichiers de l'interface manquent a cote de `gp200_studio.py`. Extraire **tout** le zip au meme niveau. |
| La chaine s'affiche sur plusieurs rangs | fenetre trop etroite pour aligner les 11 modules : elargir ou passer en plein ecran |
| Interface trop grande / trop petite | elle se cale sur la resolution au demarrage : relancer apres un changement de resolution ou de mise a l'echelle Windows |
