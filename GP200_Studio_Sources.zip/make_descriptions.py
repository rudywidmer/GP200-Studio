#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Extrait data/gp200_descriptions.json depuis description_en.xml.

Source : Resource\\GP-200\\File\\description_en.xml de l'editeur officiel.
C'est le texte que l'editeur affiche lui-meme pour chaque algorithme ; il
nomme le materiel reel, marques comprises (Marshall(R) JCM800*, Peavey(R) 5150(R)...).

Deux champs par modele :
  short : 1re phrase = l'identification du materiel. C'est ce qui part dans le
          prompt (~4400 tokens pour 305 modeles).
  full  : la description complete, gardee pour un usage ulterieur (infobulles,
          mode "affiner").

Usage : python make_descriptions.py description_en.xml
"""
import json, re, sys
import xml.etree.ElementTree as ET

src = sys.argv[1] if len(sys.argv) > 1 else "description_en.xml"
root = ET.parse(src).getroot()

out = {}
for cat_el in root.iter("Catalog"):
    for a in cat_el.iter("Algorithm"):
        code = int(a.get("ID"))
        key = "%d,%d" % (code >> 24, code & 0xFFFFFF)
        txt = re.sub(r"\s+", " ", (a.get("description") or "").strip())
        if not txt:
            continue
        # un meme Alg apparait dans plusieurs Catalog (les boosts sont en PRE
        # ET en DST) : on garde la description la plus fournie.
        if key in out and len(out[key]["full"]) >= len(txt):
            continue
        short = re.split(r"(?<=[.!])\s+", txt)[0].strip()
        # quelques descriptions n'ont pas de ponctuation finale et tiennent en
        # un seul bloc : on borne pour ne pas exploser le prompt.
        if len(short) > 150:
            short = short[:147].rsplit(" ", 1)[0] + "..."
        out[key] = {"name": a.get("Name"), "short": short, "full": txt}

# ensure_ascii=True : le fichier reste de l'ASCII pur (\u00ae au lieu de (R)).
# Il devient ainsi lisible quelle que soit la locale, meme par un code qui
# oublierait encoding="utf-8". Les descriptions sont les SEULES donnees non-ASCII
# du projet ; sans ca, sous Windows (cp1252) json.load explose.
json.dump(out, open("data/gp200_descriptions.json", "w", encoding="utf-8"),
          indent=1, ensure_ascii=True, sort_keys=True)

n_short = sum(len(v["short"]) for v in out.values())
n_full = sum(len(v["full"]) for v in out.values())
print("data/gp200_descriptions.json : %d modeles" % len(out))
print("  short : %6d car. ~%5d tokens  (part dans le prompt)" % (n_short, n_short / 4))
print("  full  : %6d car. ~%5d tokens  (reserve)" % (n_full, n_full / 4))
