# GP-200 Studio — Guia de uso

## Que es?

GP-200 Studio genera presets (archivos `.prst`) para tu **Valeton GP-200**
a partir de una simple descripcion en texto. Describes el sonido que quieres,
una IA crea el preset, y solo tienes que cargarlo en tu multi-efecto.

Ejemplos de descripciones:
- *"Clean cristalino con chorus y reverb de muelles"*
- *"Crunch bluesy calido estilo Stevie Ray Vaughan"*
- *"Metal moderno, ganancia saturada, gate cerrado, delay slapback"*
- *"Lead Pink Floyd con delay largo y reverb amplia"*


## Requisitos

- **Python 3.10+** instalado (marcar *"Add python.exe to PATH"* durante la instalacion)
- **Tkinter** incluido (viene por defecto en Windows si marcas
  *"tcl/tk and IDLE"* al instalar Python)
- **Una clave API** de al menos uno de los proveedores de IA soportados (ver mas abajo)

Nada mas que instalar: la aplicacion solo usa la biblioteca estandar de Python.


## Instalacion

1. Extraer el contenido del zip en una carpeta a tu eleccion
2. Copiar `config.example.json` como `config.json`
3. Abrir `config.json` con un editor de texto y pegar tu clave API
4. Hacer doble clic en `GP200_Studio.bat` (o ejecutar `python gp200_studio.py`)

En la primera ejecucion, la aplicacion te pedira que elijas tu idioma e
introduzcas tus claves API a traves de una ventana grafica.


## Obtener una clave API

La aplicacion necesita una clave API para comunicarse con un servicio de IA.
**Esta clave es personal y las llamadas generalmente corren por tu cuenta.**
Estas son las cuatro opciones:

### Google Gemini — recomendado para empezar
- **Coste**: gratuito (cuota limitada pero suficiente para uso normal)
- **Tarjeta bancaria**: no requerida
- **Enlace**: https://aistudio.google.com/app/apikey
- **Pasos**: inicia sesion con tu cuenta de Google, haz clic en
  *"Create API Key"*, copia la clave generada

### Anthropic Claude
- **Coste**: pago por uso (~0.003 a 0.015 $ por preset segun el modelo)
- **Tarjeta bancaria**: requerida (creditos prepago, minimo ~5 $)
- **Enlace**: https://console.anthropic.com/settings/keys
- **Pasos**: crea una cuenta, anade creditos, genera una clave API

### OpenAI (ChatGPT)
- **Coste**: pago por uso (~0.002 a 0.01 $ por preset segun el modelo)
- **Tarjeta bancaria**: requerida (creditos prepago)
- **Enlace**: https://platform.openai.com/api-keys
- **Pasos**: crea una cuenta, anade creditos, genera una clave API

### Perplexity
- **Coste**: pago por uso (busqueda web incluida en el precio)
- **Tarjeta bancaria**: requerida
- **Enlace**: https://www.perplexity.ai/settings/api
- **Pasos**: crea una cuenta, anade creditos, genera una clave API

**Seguridad**: tu clave API se almacena localmente en tu `config.json`,
cifrada en Windows via DPAPI. Nunca se envia a ningun sitio que no sea el
proveedor de IA que hayas seleccionado.


## La interfaz

```
+-----------------------------------------------------------------------+
|  GP-200 STUDIO       Nuevo / Refinar            Idioma  Claves  Salida |
+-------------------+---------------------------------------------------+
|  OPCIONES         |  DESCRIBE EL SONIDO QUE QUIERES                   |
|   proveedor       |  [ area de texto ]                                |
|   modelo          |  EJEMPLOS                                         |
|   pastilla        |  ESTRUCTURA DEL TEMA                              |
|   busqueda web    |                                                   |
|                   |  CADENA DE SENAL    <nombre del preset mostrado>  |
|  USO API          |  [PRE][WAH][DST][AMP][NR][CAB][EQ][MOD][DLY]...   |
|                   |  +-----------------------------------------+     |
|  PRESETS          |  | AMP  Mess2C+ 2             modulo 4/11  |     |
|  GENERADOS        |  | GAIN 65   PRESENCE 70   VOLUME 75  ...  |     |
|   > variante A    |  +-----------------------------------------+     |
|     variante B    |                                                   |
|     variante C    |  Resultado | Registro                             |
|     ...           |  [ informe detallado ]                            |
+-------------------+---------------------------------------------------+
|  o  estado                  Setlist | Directo |  GENERAR LOS PRESETS   |
+-----------------------------------------------------------------------+
```

La interfaz se adapta a la resolucion de tu pantalla: en una pantalla grande todo
es mas grande, en un portatil todo se aprieta. La ventana se abre al 90 % de la
pantalla, centrada.

### La cadena de senal

Los 11 modulos del preset se muestran **en una sola linea**, en el orden real de
la cadena, unidos por un cable como en una pedalera. El color indica donde estas
en la cadena:

| Color | Modulos | Papel |
|---|---|---|
| **Azul** | `PRE`, `DST`, `AMP` | lo que crea el sonido |
| **Verde** | `NR`, `CAB`, `EQ` | lo que lo moldea |
| **Magenta** | `WAH`, `MOD`, `DLY`, `RVB`, `VOL` | lo que lo colorea |

Un modulo con borde discontinuo y un `+` esta **en bypass**: en el GP-200 un slot
nunca esta vacio, simplemente esta desactivado.

Durante una generacion, **el cable se enciende modulo a modulo** y un punto
luminoso lo recorre. Ese es el indicador de progreso: te dice por donde va la
escritura del preset.

### El inspector de modulo

**Haz clic en un modulo** de la cadena: todos sus ajustes aparecen justo debajo,
con una barra en los valores entre 0 y 100.

Las tarjetas de la cadena son deliberadamente estrechas y muestran un solo
parametro, con un `+5` que indica cuantos mas esperan. Un amplificador suele
exponer seis o mas. **Las tarjetas dicen el recorrido de la senal, el inspector
dice los valores.**

Los valores sin escala conocida (un tiempo de delay en milisegundos, una
frecuencia de corte en Hz) no llevan barra — una barra falsa seria peor que
ninguna.

Este panel es de solo lectura: nunca modifica tu preset.

### Navegar por los presets generados

Una generacion escribe 3 variantes por seccion, es decir hasta 9 archivos de una
vez. La columna izquierda los lista todos, bajo **PRESETS GENERADOS**.

Haz clic en uno: la cadena se recompone, el inspector le sigue, y la ruta del
archivo aparece abajo. El nombre del preset mostrado aparece junto al titulo
*Cadena de senal* — siempre sabes que estas mirando.

Las tres variantes de una misma seccion comparten el color de su filete, asi que
los bloques `Ritmica A/B/C` y `Clean A/B/C` se reconocen de un vistazo.

La lista tambien se rellena tras un refinamiento y al cargar un `.prst`.


## Uso

### Generar presets (modo "Nuevo")

1. Elige tu **proveedor de IA** y tu **modelo** en los menus desplegables
2. Escribe tu descripcion en el area de texto (o elige un ejemplo de la lista)
3. Activa o desactiva la **busqueda web** (ayuda a la IA a identificar el equipo
   real de un artista, pero consume mas tokens)
4. Elige la **estructura**:
   - **Deteccion automatica**: la IA decide cuantos presets crear y
     como organizarlos (3, 6 o 9 presets)
   - **Forzar roles**: marca los roles que quieras
     (`clean`, `crunch`, `disto`, `lead`) — 3 presets por rol
5. Haz clic en **Generar**
6. Los archivos `.prst` se guardan en la carpeta de salida (por defecto
   `Documents\GP200_Presets`) y aparecen en la lista de la izquierda para que
   puedas revisarlos uno a uno

### Refinar un preset (modo "Refinar")

1. Cambia al modo **Refinar** con el selector de arriba
2. Carga un archivo `.prst` existente (un preset que quieras modificar).
   **Su cadena se muestra inmediatamente**, antes de cualquier llamada a la IA:
   ya puedes hacer clic en los modulos para ver sus ajustes actuales.
3. Describe los cambios que deseas en texto libre
   (*"mas ganancia"*, *"quita el delay"*, *"cambia el ampli por un Fender"*)
4. Haz clic en **Refinar**
5. La aplicacion muestra los cambios reales, comparados con el preset original

El preset original nunca se modifica: se escribe una version nueva en una
subcarpeta con marca de tiempo.

### Optimizar para directo

En modo Refinar, el boton **Optimizar para concierto** adapta un preset hecho en
casa para tocar a volumen alto: menos ganancia, menos mezcla de reverb/delay,
corte de agudos en la pantalla contra el fizz, y un ligero realce de medios. El
EQ creativo y la intencion artistica se preservan.

### Armonizar una setlist

Tambien en modo Refinar, **Armonizar setlist** te permite cargar 10 o 15 presets
y nivelar sus volumenes entre si, para que no haya saltos de nivel entre temas.
Sin llamada API, instantaneo: solo cambia el byte de volumen, y los archivos
armonizados van a una carpeta nueva.

### Cambiar de idioma

Usa el menu desplegable de idioma en la parte superior de la ventana. El cambio
es inmediato y persiste entre sesiones. Idiomas disponibles: frances, ingles,
espanol. Los presets ya generados permanecen en la lista.

### Modificar las claves API

Haz clic en el boton **Claves API** para abrir el dialogo de entrada.
Puedes configurar varias claves y cambiar de proveedor sobre la marcha.


## Copiar los presets al GP-200

1. Abre la carpeta de salida (boton **Carpeta de salida**)
2. Copia los archivos `.prst` en la tarjeta SD de tu GP-200
   (carpeta `PRESET` en la raiz de la tarjeta)
3. Inserta la tarjeta en el GP-200 e importa los presets desde el menu


## Seguimiento de consumo

Si usas un proveedor de pago (Claude, OpenAI, Perplexity), la aplicacion
muestra una estimacion del coste de cada generacion y un total acumulado.
Este seguimiento es una estimacion local basada en el numero de tokens
consumidos — comprueba tu saldo real directamente en el sitio web del
proveedor.

Puedes definir un tope de gasto en `config.json` (`budget_usd`) para
ponerte un limite visual.


## Problemas comunes

| Sintoma | Solucion |
|---------|----------|
| *"Clave API invalida"* | Verifica la clave (sin espacios al inicio/final) y el proveedor seleccionado |
| *"Modelo no reconocido"* | La IA alucino un nombre — reformula tu descripcion; la auto-correccion lo gestiona normalmente |
| Los `.prst` no se importan | Asegurate de que estan en la carpeta `PRESET` de la tarjeta SD |
| La app no arranca | Verifica que Python esta en el PATH (`python --version`) y que Tkinter funciona (`python -c "import tkinter"`) |
| Error de red / timeout | Comprueba tu conexion a internet y que el proveedor de IA es accesible |
| La cadena se parte en varias filas | La ventana es demasiado estrecha para alinear los 11 modulos. Ensanchala o maximizala. |
| La interfaz se ve muy grande o muy pequena | Se ajusta a la resolucion de tu pantalla al arrancar. Reinicia la aplicacion tras cambiar la resolucion o la escala de Windows. |

> **A tener en cuenta**: la interfaz solo tiene modo oscuro. El boton
> claro/oscuro de versiones anteriores se ha retirado; si tu `config.json` aun
> contiene una clave `"theme"`, simplemente se ignora.
