# GP-200 Studio — Guide d'utilisation

## C'est quoi ?

GP-200 Studio genere des presets (fichiers `.prst`) pour ton **Valeton GP-200**
a partir d'une simple description en texte. Tu ecris ce que tu veux entendre,
une IA cree le preset, et tu n'as plus qu'a le copier sur ta carte SD.

Exemples de descriptions :
- *"Son clean cristallin avec chorus et reverb a ressort"*
- *"Crunch blues chaud style Stevie Ray Vaughan"*
- *"Metal moderne, gain sature, gate serre, delay slapback"*
- *"Son lead Pink Floyd avec delay long et reverb ample"*


## Prerequis

- **Python 3.10+** installe (cocher *"Add python.exe to PATH"* a l'installation)
- **Tkinter** inclus (c'est le cas par defaut sur Windows si tu coches
  *"tcl/tk and IDLE"* a l'installation de Python)
- **Une cle API** pour au moins un des fournisseurs d'IA supportes (voir ci-dessous)

Aucune autre dependance a installer : l'application n'utilise que la
bibliotheque standard de Python.


## Installation

1. Extraire le contenu du zip dans un dossier de ton choix
2. Copier `config.example.json` en `config.json`
3. Ouvrir `config.json` avec un editeur de texte et coller ta cle API
4. Double-cliquer sur `GP200_Studio.bat` (ou lancer `python gp200_studio.py`)

Au premier lancement, l'application te demandera de choisir ta langue et de
saisir tes cles API via une interface graphique.


## Obtenir une cle API

L'application a besoin d'une cle API pour communiquer avec un service d'IA.
**Cette cle est personnelle et les appels sont generalement a tes frais.**
Voici les quatre options :

### Google Gemini — recommande pour debuter
- **Cout** : gratuit (quota limite mais suffisant pour un usage normal)
- **Carte bancaire** : non requise
- **Lien** : https://aistudio.google.com/app/apikey
- **Procedure** : connecte-toi avec ton compte Google, clique sur
  *"Create API Key"*, copie la cle generee

### Anthropic Claude
- **Cout** : payant a l'usage (~0.003 a 0.015 $ par preset selon le modele)
- **Carte bancaire** : requise (credits prepaid, minimum ~5 $)
- **Lien** : https://console.anthropic.com/settings/keys
- **Procedure** : cree un compte, ajoute des credits, genere une cle API

### OpenAI (ChatGPT)
- **Cout** : payant a l'usage (~0.002 a 0.01 $ par preset selon le modele)
- **Carte bancaire** : requise (credits prepaid)
- **Lien** : https://platform.openai.com/api-keys
- **Procedure** : cree un compte, ajoute des credits, genere une cle API

### Perplexity
- **Cout** : payant a l'usage (recherche web incluse dans le prix)
- **Carte bancaire** : requise
- **Lien** : https://www.perplexity.ai/settings/api
- **Procedure** : cree un compte, ajoute des credits, genere une cle API

**Securite** : ta cle API est stockee localement dans ton `config.json`,
chiffree sous Windows via DPAPI. Elle n'est jamais envoyee ailleurs qu'au
fournisseur d'IA que tu as choisi.


## L'interface

```
+-----------------------------------------------------------------------+
|  GP-200 STUDIO        Nouveau / Affiner          Langue  Cles  Dossier |
+-------------------+---------------------------------------------------+
|  OPTIONS          |  DECRIS LE SON QUE TU VEUX                        |
|   fournisseur     |  [ zone de saisie ]                               |
|   modele          |  EXEMPLES                                         |
|   micro guitare   |  STRUCTURE DU MORCEAU                             |
|   recherche web   |                                                   |
|                   |  CHAINE DE SIGNAL   <nom du preset affiche>       |
|  USAGE API        |  [PRE][WAH][DST][AMP][NR][CAB][EQ][MOD][DLY]...   |
|                   |  +-----------------------------------------+     |
|  PRESETS GENERES  |  | AMP  Mess2C+ 2              module 4/11 |     |
|   > variante A    |  | GAIN 65   PRESENCE 70   VOLUME 75  ...  |     |
|     variante B    |  +-----------------------------------------+     |
|     variante C    |                                                   |
|     ...           |  Resultat | Journal                               |
|                   |  [ compte-rendu detaille ]                        |
+-------------------+---------------------------------------------------+
|  o  statut                    Setlist | Concert |  GENERER LES PRESETS |
+-----------------------------------------------------------------------+
```

L'interface s'adapte a la resolution de ton ecran : sur un grand ecran tout est
plus grand, sur un portable tout se resserre. La fenetre s'ouvre a 90 % de
l'ecran, centree.

### La chaine de signal

Les 11 modules du preset sont affiches **sur une seule ligne**, dans l'ordre reel
de la chaine, relies par un cordon comme sur un pedalier. La couleur dit ou tu te
trouves dans la chaine :

| Couleur | Modules | Role |
|---|---|---|
| **Bleu** | `PRE`, `DST`, `AMP` | ce qui fabrique le son |
| **Vert** | `NR`, `CAB`, `EQ` | ce qui le met en forme |
| **Mauve** | `WAH`, `MOD`, `DLY`, `RVB`, `VOL` | ce qui le colore |

Un module en pointille avec un `+` est **bypasse** : sur le GP-200 un slot n'est
jamais vide, il est simplement desactive.

Pendant une generation, **le cordon s'allume module par module** et un point
lumineux le parcourt. C'est l'indicateur de progression : il te dit ou en est
l'ecriture du preset.

### L'inspecteur de module

**Clique sur un module** de la chaine : tous ses reglages s'affichent juste en
dessous, avec une jauge sur les valeurs comprises entre 0 et 100.

Les cartes de la chaine sont volontairement etroites et n'affichent qu'un
parametre, avec un `+5` qui indique combien d'autres attendent. Un ampli en expose
souvent six ou plus. **Les cartes disent le trajet du signal, l'inspecteur dit les
valeurs.**

Les valeurs sans echelle connue (un temps de delay en millisecondes, une frequence
de coupure en Hz) n'ont pas de jauge — une jauge fausse serait pire que pas de
jauge.

Cet affichage est en lecture seule : il ne modifie jamais ton preset.

### Naviguer dans les presets generes

Une generation ecrit 3 variantes par section, donc jusqu'a 9 fichiers d'un coup.
La colonne de gauche les liste tous, sous **PRESETS GENERES**.

Clique sur l'un d'eux : la chaine se recompose, l'inspecteur suit, et le chemin
du fichier s'affiche en bas de la fenetre. Le nom du preset affiche apparait a
cote du titre *Chaine de signal* — tu sais toujours ce que tu regardes.

Les trois variantes d'une meme section partagent la couleur de leur liseré : tu
reperes d'un coup d'oeil les blocs `Rythmique A/B/C` et `Clean A/B/C`.

La liste se remplit aussi apres un affinage et au chargement d'un `.prst`.


## Utilisation

### Generer des presets (mode "Nouveau")

1. Choisis ton **fournisseur d'IA** et ton **modele** dans les menus deroulants
2. Ecris ta description dans la zone de texte (ou choisis un exemple dans la liste)
3. Active ou desactive la **recherche web** (aide l'IA a identifier le vrai
   equipement d'un artiste, mais consomme plus de tokens)
4. Choisis la **structure** :
   - **Detection automatique** : l'IA decide combien de presets creer et
     comment les organiser (3, 6 ou 9 presets)
   - **Forcer les roles** : tu coches les roles que tu veux
     (`clean`, `crunch`, `disto`, `lead`) — 3 presets par role
5. Clique sur **Generer**
6. Les fichiers `.prst` sont ecrits dans le dossier de sortie
   (par defaut, `Documents\GP200_Presets`), et apparaissent dans la liste de
   gauche pour que tu puisses les examiner un par un

### Affiner un preset (mode "Affiner")

1. Passe en mode **Affiner** via le selecteur en haut
2. Charge un fichier `.prst` existant (un preset que tu veux modifier).
   **Sa chaine s'affiche immediatement**, avant tout appel a l'IA : tu peux deja
   cliquer les modules pour voir leurs reglages actuels.
3. Decris les modifications souhaitees en texte libre
   (*"plus de gain"*, *"enleve le delay"*, *"change l'ampli pour un Fender"*)
4. Clique sur **Affiner**
5. L'application montre les changements reels, compares avec le preset original

Le preset d'origine n'est jamais modifie : une nouvelle version est ecrite dans un
sous-dossier horodate.

### Optimiser pour le concert

En mode Affiner, le bouton **Optimiser pour concert** adapte un preset fait a la
maison pour le jeu a fort volume : reduction du gain et des mix de reverb/delay,
coupe-haut sur le baffle contre la fizz, leger boost de mediums. L'intention
artistique et l'EQ creatif sont preserves.

### Harmoniser une setlist

Toujours en mode Affiner, **Harmoniser setlist** te laisse charger 10 ou 15
presets et egalise leurs volumes entre eux, pour ne pas avoir de saut de niveau
d'un morceau a l'autre. Aucun appel API, c'est instantane : seul l'octet de volume
change, et les fichiers harmonises partent dans un nouveau dossier.

### Changer de langue

Utilise le menu deroulant de langue en haut de la fenetre. Le changement est
immediat et persiste entre les sessions. Langues disponibles : francais,
anglais, espagnol. Les presets deja generes restent dans la liste.

### Modifier les cles API

Clique sur le bouton **Cles API** pour ouvrir le dialogue de saisie.
Tu peux configurer plusieurs cles et changer de fournisseur a la volee.


## Copier les presets sur le GP-200

1. Ouvre le dossier de sortie (bouton **Dossier de sortie**)
2. Copie les fichiers `.prst` sur la carte SD de ton GP-200
   (dossier `PRESET` a la racine de la carte)
3. Insere la carte dans le GP-200 et importe les presets depuis le menu


## Suivi de consommation

Si tu utilises un fournisseur payant (Claude, OpenAI, Perplexity),
l'application affiche une estimation du cout de chaque generation et un
cumul des depenses. Ce suivi est une estimation locale basee sur le nombre
de tokens consommes — verifie ton solde reel directement sur le site du
fournisseur.

Tu peux definir un plafond de depense dans `config.json` (`budget_usd`)
pour te fixer une limite visuelle.


## Problemes courants

| Symptome | Solution |
|----------|----------|
| *"Cle API invalide"* | Verifie la cle (pas d'espace en debut/fin) et le fournisseur selectionne |
| *"Modele non reconnu"* | L'IA a hallucine un nom — reformule ta description, l'auto-correction le gere normalement |
| Les `.prst` ne s'importent pas | Verifie qu'ils sont dans le dossier `PRESET` de la carte SD |
| L'appli ne se lance pas | Verifie Python dans le PATH (`python --version`) et Tkinter (`python -c "import tkinter"`) |
| Erreur reseau / timeout | Verifie ta connexion internet et que le fournisseur d'IA est accessible |
| La chaine s'affiche sur plusieurs rangs | La fenetre est trop etroite pour aligner les 11 modules. Elargis-la, ou passe-la en plein ecran. |
| L'interface parait trop grande ou trop petite | Elle se cale sur la resolution de ton ecran au demarrage. Redemarre l'application apres un changement de resolution ou de mise a l'echelle Windows. |

> **A savoir** : l'interface n'a qu'un mode sombre. Le bouton clair/sombre des
> versions precedentes a ete retire ; si ton `config.json` contient encore une
> cle `"theme"`, elle est simplement ignoree.
