#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GP-200 Studio -- Maquette vivante du design "Retro-Future Hardware".

    python design_preview.py

Fenetre autonome, donnees fictives, ZERO appel a la logique metier. Elle sert
a valider le design en vrai avant de toucher a gp200_studio.py : rien ici ne
peut casser l'appli existante.

A essayer :
  * survoler les cartes de la chaine (halo par famille)
  * cliquer une carte (selection) et un preset dans la colonne de gauche
  * cliquer "Generer" : la trace de signal s'allume module par module.
    C'est la barre de progression. Il n'y en a pas d'autre.
"""

import sys

try:
    import tkinter as tk
    from tkinter import ttk
except ImportError as e:                               # pragma: no cover
    sys.stderr.write("Tkinter introuvable (%s).\n"
                     "  Windows : reinstaller Python en cochant 'tcl/tk'\n"
                     "  Linux   : sudo apt install python3-tk\n" % e)
    raise SystemExit(1)

from gp200_theme import (TOK, CAT, SLOT_CAT, FONT, UI_SCALE,
                         apply_theme, sil, mix, set_ui_lang)
from gp200_ui import (GradientStrip, Silk, Led, Chip, GlowButton, VMeter,
                      SignalRack, PresetList, Well, ModuleInspector)


# =============================================================================
#  Donnees de demonstration
# =============================================================================

DEMO_CHAIN = [
    {"slot": "PRE", "model": "COMP",        "on": True,
     "params": {"Sustain": 42, "Level": 55}},
    {"slot": "WAH", "model": "V-Wah",       "on": False, "params": {}},
    {"slot": "DST", "model": "Green OD",    "on": True,
     "params": {"Drive": 38, "Tone": 61}},
    {"slot": "AMP", "model": "EV 51",       "on": True,
     "params": {"Gain": 62, "Presence": 70, "Volume": 78, "Bass": 35,
                "Middle": 45, "Treble": 65}},
    {"slot": "NR",  "model": "Gate 1",      "on": True,
     "params": {"Thresh": 24, "Decay": 40}},
    {"slot": "CAB", "model": "Mess 4x12",   "on": True,
     "params": {"HiCut": 8500, "Level": 50}},
    {"slot": "EQ",  "model": "Guitar EQ 1", "on": True,
     "params": {"Mid": 58, "Presence": 52}},
    {"slot": "MOD", "model": "G-Chorus",    "on": False, "params": {}},
    {"slot": "DLY", "model": "Ping Pong",   "on": True,
     "params": {"Time": 420, "Mix": 22}},
    {"slot": "RVB", "model": "Room",        "on": True,
     "params": {"Decay": 34, "Mix": 18}},
    {"slot": "VOL", "model": "Volume",      "on": True,
     "params": {"Level": 78}},
]

DEMO_PRESETS = [
    {"name": "MOP_Rythm_Fid",   "meta": "AMP EV 51 - gain 62",     "cat": "GEN"},
    {"name": "MOP_Rythm_live",  "meta": "concert - gain 50",       "cat": "GEN"},
    {"name": "BIB_Crunch",      "meta": "AMP Plexi - gain 55",     "cat": "GEN"},
    {"name": "MOP_Clean",       "meta": "AMP J-120 CL",            "cat": "GEN"},
    {"name": "Enter_Sandman",   "meta": "DST Metal Zone",          "cat": "GEN"},
    {"name": "Creep_Clean",     "meta": "MOD G-Chorus",            "cat": "FX"},
    {"name": "Creep_Blast",     "meta": "DST Big Muff",            "cat": "GEN"},
    {"name": "Numb_Verse",      "meta": "DLY Ping Pong 420 ms",    "cat": "FX"},
    {"name": "Numb_Chorus",     "meta": "RVB Hall - mix 30",       "cat": "FX"},
    {"name": "Bad_Reputation",  "meta": "CAB 4x12 Mess",           "cat": "CAB"},
    {"name": "Highway_to_Hell", "meta": "AMP Marsh JMP",           "cat": "GEN"},
    {"name": "Back_in_Black",   "meta": "CAB 4x12 - HiCut 9k",     "cat": "CAB"},
    {"name": "Seven_Nation",    "meta": "DST Octave Fuzz",         "cat": "GEN"},
    {"name": "Zombie_Verse",    "meta": "MOD Flanger",             "cat": "FX"},
    {"name": "Solo_Lead_A",     "meta": "EQ mid +6 dB",            "cat": "CAB"},
]

EXEMPLES = [
    "un crunch annees 70 pour Highway to Hell, micro humbucker",
    "clean chorus tres large facon Radiohead, reverbe longue",
    "gros rythmique metal moderne, serree, sans bave dans les graves",
    "lead cremeux avec delay dotte a 420 ms",
]


# =============================================================================
#  Fenetre
# =============================================================================

class Preview(tk.Tk):

    def __init__(self):
        tk.Tk.__init__(self)
        apply_theme(self)
        set_ui_lang("fr")
        self.title("GP-200 Studio  -  maquette design")
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        w = max(940, min(int(sw * 0.90), 1720))
        h = max(620, min(int(sh * 0.88), 1060))
        self.geometry("%dx%d+%d+%d" % (w, h, max(0, (sw - w) // 2),
                                       max(0, (sh - h) // 2 - 16)))
        self.minsize(940, 620)
        self.configure(bg=TOK["bg_deep"])

        self._build_header()
        # le pied AVANT le corps : sinon le corps en expand=True absorbe
        # toute la cavite et le pied se retrouve sans hauteur
        self._build_footer()
        self._build_body()

        self.rack.set_slots(DEMO_CHAIN)
        self.rack.select(3)
        self.insp.set_module(DEMO_CHAIN[3], pos=(3, len(DEMO_CHAIN)))
        self.presets.set_items(DEMO_PRESETS)
        self._gen_job = None

    # ---------------------------------------------------------------- header
    def _build_header(self):
        hd = GradientStrip(self, top=TOK["bg_panel"], bot=TOK["bg_panel"],
                           height=int(62 * UI_SCALE[0]),
                           line=TOK["line_soft"])
        hd.pack(fill="x", side="top")

        left = tk.Frame(hd, bg=TOK["bg_panel"])
        left.place(x=TOK["pad_lg"], rely=0.5, anchor="w")
        # pastille de marque : le seul aplat cyan de la barre
        mark = tk.Canvas(left, width=30, height=30, bg=TOK["bg_panel"],
                         highlightthickness=0, bd=0)
        mark.pack(side="left", padx=(0, 12))
        from gp200_ui import fill_round_rect, stroke_round_rect
        fill_round_rect(mark, 1, 1, 29, 29, 8, mix(TOK["acc_hi"], "#ffffff", .2),
                        TOK["acc_lo"])
        stroke_round_rect(mark, 1, 1, 29, 29, 8, mix(TOK["acc_hi"], "#fff", .4))
        mark.create_text(15, 15, text="GP", fill=TOK["acc_ink"],
                         font=(FONT["family_display"], 12, "bold"))

        tt = tk.Frame(left, bg=TOK["bg_panel"])
        tt.pack(side="left")
        tk.Label(tt, text=sil("GP-200 STUDIO", 1), bg=TOK["bg_panel"],
                 fg=TOK["ink"], font=FONT["h1"]).pack(anchor="w")
        tk.Label(tt, text="v2.4.0   -   Valeton GP-200", bg=TOK["bg_panel"],
                 fg=TOK["ink_ghost"], font=FONT["micro"]).pack(anchor="w")

        # selecteur de mode, facon interrupteur a glissiere de facade
        mid = tk.Frame(hd, bg=TOK["bg_panel"])
        mid.place(relx=0.5, rely=0.5, anchor="center")
        self.var_mode = tk.StringVar(value="new")
        for val, lbl in (("new", "Nouveau"), ("refine", "Affiner")):
            ttk.Radiobutton(mid, text=lbl, value=val, variable=self.var_mode,
                            command=self._on_mode).pack(side="left", padx=10)

        right = tk.Frame(hd, bg=TOK["bg_panel"])
        right.place(relx=1.0, x=-TOK["pad_lg"], rely=0.5, anchor="e")
        cb = ttk.Combobox(right, state="readonly", width=10,
                          values=["Francais", "English", "Espanol"])
        cb.current(0)
        cb.pack(side="left", padx=(0, 8))
        ttk.Button(right, text="\u263e", width=3,
                   style="Ghost.TButton").pack(side="left", padx=2)
        ttk.Button(right, text="\u2699", width=3,
                   style="Ghost.TButton").pack(side="left", padx=2)

    # ------------------------------------------------------------------ body
    def _build_body(self):
        body = tk.Frame(self, bg=TOK["bg_deep"])
        body.pack(fill="both", expand=True)

        # ---- colonne de gauche : presets
        side = tk.Frame(body, bg=TOK["bg_panel"], width=TOK["sidebar_w"])
        side.pack(side="left", fill="y")
        side.pack_propagate(False)

        sh = tk.Frame(side, bg=TOK["bg_panel"])
        sh.pack(fill="x", padx=TOK["pad_md"], pady=(TOK["pad_md"], 6))
        Silk(sh, "Presets").pack(side="left")
        tk.Label(sh, text="15", bg=TOK["bg_panel"], fg=TOK["ink_ghost"],
                 font=FONT["data"]).pack(side="right")

        sw = Well(side, bg=TOK["bg_panel"], height=30, pad=6)
        sw.pack(fill="x", padx=TOK["pad_md"], pady=(0, 10))
        ent = tk.Entry(sw, bg=TOK["bg_field"], fg=TOK["ink"], bd=0,
                       highlightthickness=0, insertbackground=TOK["acc"],
                       font=FONT["small"])
        ent.insert(0, "filtrer...")
        sw.mount(ent)

        self.presets = PresetList(side, on_select=self._on_preset)
        self.presets.pack(fill="both", expand=True, padx=(6, 2),
                          pady=(0, TOK["pad_md"]))

        tk.Frame(body, bg=TOK["line_soft"], width=1).pack(side="left", fill="y")

        # ---- colonne principale
        main = tk.Frame(body, bg=TOK["bg_top"])
        main.pack(side="left", fill="both", expand=True)

        # demande
        dz = tk.Frame(main, bg=TOK["bg_top"])
        dz.pack(fill="x", padx=TOK["pad_lg"], pady=(TOK["pad_lg"], 0))
        hdr = tk.Frame(dz, bg=TOK["bg_top"])
        hdr.pack(fill="x")
        Silk(hdr, "Demande", bg=TOK["bg_top"]).pack(side="left")
        tk.Label(hdr, text="decris le son, pas les reglages",
                 bg=TOK["bg_top"], fg=TOK["ink_ghost"],
                 font=FONT["small"]).pack(side="left", padx=10)

        well = Well(dz, bg=TOK["bg_top"], height=76)
        well.pack(fill="x", pady=(6, 8))
        txt = tk.Text(well, height=3, wrap="word", bd=0, highlightthickness=0,
                      bg=TOK["bg_field"], fg=TOK["ink"], font=FONT["body"],
                      insertbackground=TOK["acc"])
        txt.insert("1.0", EXEMPLES[0])
        well.mount(txt)

        ex = tk.Frame(dz, bg=TOK["bg_top"])
        ex.pack(fill="x")
        Silk(ex, "Exemples", bg=TOK["bg_top"]).pack(side="left", padx=(0, 8))
        cbe = ttk.Combobox(ex, state="readonly", values=EXEMPLES, width=52)
        cbe.current(0)
        cbe.pack(side="left")

        # barre de meta du preset courant
        meta = tk.Frame(main, bg=TOK["bg_top"])
        meta.pack(fill="x", padx=TOK["pad_lg"], pady=(TOK["pad_lg"], 6))
        tk.Label(meta, text="MOP_Rythm_Fid", bg=TOK["bg_top"], fg=TOK["ink"],
                 font=FONT["h2"]).pack(side="left")
        tk.Label(meta, text="1224 o - checksum OK", bg=TOK["bg_top"],
                 fg=TOK["ok"], font=FONT["small"]).pack(side="left", padx=12)

        vw = tk.Frame(meta, bg=TOK["bg_top"])
        vw.pack(side="right")
        tk.Label(vw, text=sil("patch vol"), bg=TOK["bg_top"],
                 fg=TOK["ink_label"], font=FONT["micro"]).pack(anchor="e")
        self.meter = VMeter(vw, bg=TOK["bg_top"], width=160, target=0.72)
        self.meter.pack(anchor="e", pady=(2, 0))
        self.meter.set(0.78)

        for name, n, cat in (("Effet", 5, "FX"), ("Cabinet", 3, "CAB"),
                             ("Generateur", 3, "GEN")):
            Chip(meta, name, str(n), bg=TOK["bg_top"],
                 fg=TOK["ink_label"],
                 accent=CAT[cat]["light"], width=112).pack(side="right", padx=4)

        # entete de la chaine
        ch = tk.Frame(main, bg=TOK["bg_top"])
        ch.pack(fill="x", padx=TOK["pad_lg"])
        Silk(ch, "Chaine de signal", bg=TOK["bg_top"]).pack(side="left")
        self.lbl_chain = tk.Label(ch, text="11 modules  -  9 actifs, 2 bypass",
                                  bg=TOK["bg_top"], fg=TOK["ink_ghost"],
                                  font=FONT["small"])
        self.lbl_chain.pack(side="left", padx=10)

        # le rack
        rw = tk.Frame(main, bg=TOK["bg_rail"], highlightthickness=1,
                      highlightbackground=TOK["line_soft"])
        rw.pack(fill="x", expand=False, padx=TOK["pad_lg"],
                pady=(6, TOK["pad_lg"]))
        self.rack = SignalRack(rw, on_click=self._on_slot,
                               height=int(150 * UI_SCALE[0]))
        self.rack.pack(fill="x", expand=False)
        self.insp = ModuleInspector(rw, bg=TOK["bg_rail"],
                                    height=int(70 * UI_SCALE[0]))
        self.insp.pack(fill="x", expand=False)

    # ---------------------------------------------------------------- footer
    def _build_footer(self):
        ft = GradientStrip(self, top=TOK["bg_panel"], bot=TOK["bg_panel"],
                           height=int(66 * UI_SCALE[0]))
        ft.pack(fill="x", side="bottom")
        ft.create_line(0, 0, 4000, 0, fill=TOK["line_soft"])

        left = tk.Frame(ft, bg=TOK["bg_panel"])
        left.place(x=TOK["pad_lg"], rely=0.5, anchor="w")
        self.led = Led(left, on=True, size=9)
        self.led.pack(side="left", padx=(0, 8))
        self.lbl_status = tk.Label(left, text="Pret", bg=TOK["bg_panel"],
                                   fg=TOK["ink_dim"], font=FONT["small"])
        self.lbl_status.pack(side="left")

        right = tk.Frame(ft, bg=TOK["bg_panel"])
        right.place(relx=1.0, x=-TOK["pad_lg"], rely=0.5, anchor="e")
        self.btn_gen = GlowButton(right, text="Generer", icon="\u26a1",
                                  bg=TOK["bg_panel"], command=self._fake_run)
        self.btn_gen.pack(side="right")
        ttk.Button(right, text="Peaufiner",
                   command=self._fake_run).pack(side="right", padx=(0, 14))
        ttk.Button(right, text="Harmoniser setlist",
                   style="Ghost.TButton").pack(side="right", padx=(0, 6))

    # -------------------------------------------------------------- callbacks
    def _on_mode(self):
        self._status("Mode : %s" % ("nouveau preset"
                                    if self.var_mode.get() == "new"
                                    else "affiner un preset existant"))

    def _on_preset(self, i, item):
        self._status("Preset : %s" % item["name"])

    def _on_slot(self, i, s):
        self.insp.set_module(s, pos=(i, len(DEMO_CHAIN)))
        state = "actif" if s.get("on", True) else "bypass"
        self._status("%s  -  %s  (%s)" % (s["slot"], s.get("model") or "-",
                                          state))

    def _status(self, msg):
        self.lbl_status.configure(text=msg)

    # ---- demonstration : la trace de signal EST la barre de progression -----
    def _fake_run(self):
        if self._gen_job:
            return
        self.btn_gen.set_busy(True)
        self.btn_gen.set_enabled(False)
        self.rack.set_progress(-1)
        self.rack.start_flow()
        self.led.set(False)
        self._status("Appel du modele...")
        self._step(0)

    def _step(self, k):
        n = len(DEMO_CHAIN)
        if k >= n:
            self.rack.stop_flow()
            self.btn_gen.set_busy(False)
            self.btn_gen.set_enabled(True)
            self.led.set(True)
            self._status("11 modules ecrits  -  checksum OK")
            self._gen_job = None
            return
        self.rack.set_progress(k)
        self._status("Ecriture du module %s (%d/%d)"
                     % (DEMO_CHAIN[k]["slot"], k + 1, n))
        self._gen_job = self.after(260, lambda: self._step(k + 1))


if __name__ == "__main__":
    Preview().mainloop()
