# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['gp200_studio.py'],
    pathex=['.'],
    binaries=[],
    datas=[('data', 'data'), ('template.prst', '.'), ('icon.ico', '.')],
    hiddenimports=['gp200lib', 'gp200_agent', 'gp200_i18n', 'gp200_secrets', 'gp200_setlist', 'gp200_theme', 'gp200_ui', 'gp200_oauth', 'gp200_lufs', 'gp200_calibration', 'gp200_batch', 'gp200_batch_live', 'gp200_midi', 'gp200_usb', 'sounddevice', 'pyloudnorm', 'mido'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='GP200_Studio',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['icon.ico'],
)
