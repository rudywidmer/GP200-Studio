# -*- coding: utf-8 -*-
"""Traductions de l'interface GP-200 Studio (FR / EN / ES).

Toutes les chaines ASCII-safe (\\uXXXX) pour rester lisibles quelle que soit la
locale du systeme, comme le reste des donnees du projet.

Usage :
    from gp200_i18n import T, set_lang, LANGS
    set_lang("fr")
    T("generate_button")        -> "Generer les presets"
    T("count_sections", n=3)    -> "3 sections"
"""

LANGS = {"fr": "Francais", "en": "English", "es": "Espanol"}
DEFAULT_LANG = "fr"

# Version de l'application. Apparait dans le titre et le nom de l'exe.
APP_VERSION = "0.3"

# Contact et lien de don. Adresse email de secours si le message Ko-fi
# Lien Ko-fi de l'auteur (item Shop a prix libre). Stripe connecte en plus de
# PayPal cote Ko-fi : les acheteurs peuvent payer par carte sans compte PayPal.
_STRINGS = {
    # -- mode (radio haut de fenetre)
    "mode_new": {
        "fr": "Nouveau morceau",
        "en": "New song",
        "es": "Nuevo tema"},
    "mode_refine": {
        "fr": "Affiner un preset existant",
        "en": "Refine an existing preset",
        "es": "Refinar un preset existente"},

    # -- champ de saisie selon le mode
    "refine_title": {
        "fr": "Que veux-tu changer sur ce preset ?",
        "en": "What do you want to change on this preset?",
        "es": "\u00bfQue quieres cambiar en este preset?"},
    "refine_sub": {
        "fr": "En clair : \"trop de reverb, il manque un flanger, ampli plus sature\".",
        "en": "In plain words: \"too much reverb, add a flanger, more amp gain\".",
        "es": "En claro: \"demasiada reverb, falta un flanger, mas ganancia de amp\"."},

    # -- web search + structure
    "web_search": {
        "fr": "Recherche web (identifier le vrai rig)",
        "en": "Web search (identify the real rig)",
        "es": "Busqueda web (identificar el equipo real)"},
    "auto_detect": {
        "fr": "Detection automatique (le modele decide combien de sons distincts "
              "a le morceau)",
        "en": "Auto-detect (the model decides how many distinct sounds the song has)",
        "es": "Deteccion automatica (el modelo decide cuantos sonidos distintos "
              "tiene el tema)"},
    "structure_hint_auto": {
        "fr": "Le modele determine la structure : 1 son = 3 presets, 2 sons = 6, "
              "3 sons = 9.",
        "en": "The model determines the structure: 1 sound = 3 presets, 2 = 6, 3 = 9.",
        "es": "El modelo determina la estructura: 1 sonido = 3 presets, 2 = 6, 3 = 9."},
    "structure_hint_pick": {
        "fr": "Coche au moins un role, ou remets la detection automatique.",
        "en": "Tick at least one role, or switch auto-detect back on.",
        "es": "Marca al menos un rol, o vuelve a la deteccion automatica."},
    "structure_forced": {
        "fr": "%d section(s) imposee(s) : %s  ->  %d presets",
        "en": "%d forced section(s): %s  ->  %d presets",
        "es": "%d seccion(es) impuesta(s): %s  ->  %d presets"},

    # -- fichier charge
    "loaded_fmt": {"fr": "%s  -  %r%s", "en": "%s  -  %r%s", "es": "%s  -  %r%s"},

    # -- usage / cout
    "usage_gemini": {
        "fr": "Gemini : pas de suivi de cout (tarification cote Google).",
        "en": "Gemini: no cost tracking (pricing handled by Google).",
        "es": "Gemini: sin seguimiento de coste (tarifas gestionadas por Google)."},
    "usage_budget": {
        "fr": "Budget $%.2f   depense $%.3f   reste $%.2f (%.0f%%)   %d appels",
        "en": "Budget $%.2f   spent $%.3f   left $%.2f (%.0f%%)   %d calls",
        "es": "Presupuesto $%.2f   gastado $%.3f   queda $%.2f (%.0f%%)   %d llamadas"},
    "usage_cumul": {
        "fr": "Depense cumulee $%.3f sur %d appels",
        "en": "Cumulative spend $%.3f over %d calls",
        "es": "Gasto acumulado $%.3f en %d llamadas"},
    "usage_session": {
        "fr": "session $%.4f",
        "en": "session $%.4f",
        "es": "sesion $%.4f"},
    "usage_quota": {
        "fr": "   |   quota minute : ",
        "en": "   |   per-minute quota: ",
        "es": "   |   cuota por minuto: "},

    # -- statuts
    "status_models_query": {
        "fr": "Interrogation des modeles...",
        "en": "Querying models...",
        "es": "Consultando modelos..."},
    "status_models_avail": {
        "fr": "%d modeles disponibles",
        "en": "%d models available",
        "es": "%d modelos disponibles"},
    "status_refined": {
        "fr": "preset affine (%d changement(s))   |   %s",
        "en": "preset refined (%d change(s))   |   %s",
        "es": "preset refinado (%d cambio(s))   |   %s"},
    "status_generated": {
        "fr": "%d presets / %d section(s)   |   %s",
        "en": "%d presets / %d section(s)   |   %s",
        "es": "%d presets / %d seccion(es)   |   %s"},

    # -- onglet journal
    "log_tab": {"fr": "Journal", "en": "Log", "es": "Registro"},"keys_get": {
        "fr": "Obtenir une cle \u2192",
        "en": "Get a key \u2192",
        "es": "Obtener una clave \u2192"},
    "keys_perplexity": {"fr": "Cle Perplexity :",
                        "en": "Perplexity key:",
                        "es": "Clave Perplexity:"},
    "keys_openai": {"fr": "Cle OpenAI :",
                    "en": "OpenAI key:",
                    "es": "Clave OpenAI:"},
    "keys_help_intro": {
        "fr": "Pas de cle ? Clique sur \u00ab Obtenir une cle \u00bb : chaque lien "
              "ouvre la page ou creer la tienne.",
        "en": "No key? Click \u00ab Get a key \u00bb: each link opens the page to "
              "create yours.",
        "es": "\u00bfSin clave? Haz clic en \u00ab Obtener una clave \u00bb: cada "
              "enlace abre la pagina para crear la tuya."},

    "prov_gemini": {
        "fr": "Google Gemini (offre gratuite, sans CB)",
        "en": "Google Gemini (free tier, no card)",
        "es": "Google Gemini (plan gratuito, sin tarjeta)"},
    "prov_anthropic": {
        "fr": "Anthropic Claude (payant a l'usage)",
        "en": "Anthropic Claude (pay as you go)",
        "es": "Anthropic Claude (pago por uso)"},
    "prov_perplexity": {
        "fr": "Perplexity (payant, recherche web incluse)",
        "en": "Perplexity (paid, web search included)",
        "es": "Perplexity (de pago, busqueda web incluida)"},
    "prov_openai": {
        "fr": "OpenAI (ChatGPT - payant a l'usage)",
        "en": "OpenAI (ChatGPT - pay as you go)",
        "es": "OpenAI (ChatGPT - pago por uso)"},

    "pickup_label": {"fr": "Micro guitare :", "en": "Guitar pickup:",
                     "es": "Pastilla guitarra:"},
    "pickup_auto": {"fr": "Non precise (le modele decide)",
                    "en": "Unspecified (model decides)",
                    "es": "Sin especificar (decide el modelo)"},
    "pickup_humbucker": {"fr": "Humbucker (double bobinage)",
                         "en": "Humbucker",
                         "es": "Humbucker (doble bobina)"},
    "pickup_single": {"fr": "Simple bobinage",
                      "en": "Single-coil",
                      "es": "Bobina simple"},
    "pickup_p90": {"fr": "P90", "en": "P90", "es": "P90"},
    "pickup_active": {"fr": "Actif (EMG, etc.)",
                      "en": "Active (EMG, etc.)",
                      "es": "Activa (EMG, etc.)"},

    "res_rig": {"fr": "RIG IDENTIFIE", "en": "IDENTIFIED RIG",
                "es": "EQUIPO IDENTIFICADO"},
    "res_structure": {"fr": "STRUCTURE", "en": "STRUCTURE", "es": "ESTRUCTURA"},
    "res_section": {"fr": "SECTION", "en": "SECTION", "es": "SECCION"},
    "res_axe": {"fr": "axe", "en": "angle", "es": "enfoque"},
    "res_ecoute": {"fr": "ecoute", "en": "listen", "es": "escucha"},
    "res_file": {"fr": "fichier", "en": "file", "es": "archivo"},

    "ex_1": {
        "fr": "Master of Puppets - Metallica, son rythmique album",
        "en": "Master of Puppets - Metallica, album rhythm tone",
        "es": "Master of Puppets - Metallica, sonido ritmico del album"},
    "ex_2": {
        "fr": "Nothing Else Matters - Metallica, du clean d'intro au solo",
        "en": "Nothing Else Matters - Metallica, from intro clean to solo",
        "es": "Nothing Else Matters - Metallica, del limpio de intro al solo"},
    "ex_3": {
        "fr": "Comfortably Numb - Pink Floyd, couplet clean et solo final",
        "en": "Comfortably Numb - Pink Floyd, clean verse and final solo",
        "es": "Comfortably Numb - Pink Floyd, estrofa limpia y solo final"},
    "ex_4": {
        "fr": "Sultans of Swing - Dire Straits, son clean Strat",
        "en": "Sultans of Swing - Dire Straits, clean Strat tone",
        "es": "Sultans of Swing - Dire Straits, sonido limpio de Strat"},
    "ex_5": {
        "fr": "Panama - Van Halen",
        "en": "Panama - Van Halen",
        "es": "Panama - Van Halen"},
    "ex_6": {
        "fr": "Bulls on Parade - Rage Against the Machine",
        "en": "Bulls on Parade - Rage Against the Machine",
        "es": "Bulls on Parade - Rage Against the Machine"},
    "ex_7": {
        "fr": "Sweet Child O' Mine - Guns N' Roses, riff intro, couplet et solo",
        "en": "Sweet Child O' Mine - Guns N' Roses, intro riff, verse and solo",
        "es": "Sweet Child O' Mine - Guns N' Roses, riff de intro, estrofa y solo"},
    "ex_8": {
        "fr": "Un clean chaud type jazz manouche pour une intro",
        "en": "A warm gypsy-jazz clean for an intro",
        "es": "Un limpio calido tipo jazz manouche para una intro"},
    "exa_1": {
        "fr": "Il y a trop de reverb, et il manque un flanger",
        "en": "Too much reverb, and a flanger is missing",
        "es": "Hay demasiada reverb, y falta un flanger"},
    "exa_2": {
        "fr": "Pas assez de gain, et le son est trop sourd dans les aigus",
        "en": "Not enough gain, and the tone is too dull on the highs",
        "es": "No hay suficiente ganancia, y el sonido es muy apagado en agudos"},
    "exa_3": {
        "fr": "Ajoute un delay en croche pointee, mix discret",
        "en": "Add a dotted-eighth delay, subtle mix",
        "es": "Anade un delay en corchea con puntillo, mezcla discreta"},
    "exa_4": {
        "fr": "Enleve le chorus, mets un phaser a la place",
        "en": "Remove the chorus, put a phaser instead",
        "es": "Quita el chorus, pon un phaser en su lugar"},
    "exa_5": {
        "fr": "Trop de basses, ca bave en groupe : resserre le bas",
        "en": "Too much bass, it gets muddy with the band: tighten the low end",
        "es": "Demasiados graves, se emborrona en grupo: ajusta los bajos"},
    "exa_6": {
        "fr": "Coupe tous les effets temps, je veux le son brut",
        "en": "Cut all time-based effects, I want the raw tone",
        "es": "Corta todos los efectos de tiempo, quiero el sonido crudo"},
    "exa_7": {
        "fr": "Rends-le utilisable en clean : baisse le gain de l'ampli",
        "en": "Make it usable clean: lower the amp gain",
        "es": "Hazlo utilizable en limpio: baja la ganancia del amp"},

    "gen_cost": {
        "fr": "Cout de cette generation : $%.4f",
        "en": "Cost of this generation: $%.4f",
        "es": "Coste de esta generacion: $%.4f"},

    # -- journal / logs
    "log_tokens": {
        "fr": "    tokens : entree=%s cache_ecrit=%s cache_lu=%s sortie=%s | %d recherche(s)",
        "en": "    tokens: in=%s cache_write=%s cache_read=%s out=%s | %d search(es)",
        "es": "    tokens: entrada=%s cache_escrito=%s cache_leido=%s salida=%s | %d busqueda(s)"},
    "log_tokens_simple": {
        "fr": "    tokens : entree=%s sortie=%s",
        "en": "    tokens: in=%s out=%s",
        "es": "    tokens: entrada=%s salida=%s"},
    "log_cost": {
        "fr": "    cout appel : $%.4f  |  total session : $%.4f",
        "en": "    call cost: $%.4f  |  session total: $%.4f",
        "es": "    coste llamada: $%.4f  |  total sesion: $%.4f"},
    "log_quota": {
        "fr": "    quota minute : %s",
        "en": "    per-minute quota: %s",
        "es": "    cuota por minuto: %s"},
    "log_truncated": {
        "fr": "    ! REPONSE TRONQUEE : max_tokens=%d atteint (sortie %s tokens).",
        "en": "    ! RESPONSE TRUNCATED: max_tokens=%d reached (output %s tokens).",
        "es": "    ! RESPUESTA TRUNCADA: max_tokens=%d alcanzado (salida %s tokens)."},
    "log_truncated_simple": {
        "fr": "    ! REPONSE TRONQUEE : limite de tokens atteinte.",
        "en": "    ! RESPONSE TRUNCATED: token limit reached.",
        "es": "    ! RESPUESTA TRUNCADA: limite de tokens alcanzado."},
    "log_api_attempt": {
        "fr": "  appel API (tentative %d)...",
        "en": "  API call (attempt %d)...",
        "es": "  llamada API (intento %d)..."},
    "log_json_cut": {
        "fr": "  ! JSON coupe par la limite de tokens : on repart en demandant "
              "plus court (reponse cassee non renvoyee)",
        "en": "  ! JSON cut by token limit: retrying with a shorter request "
              "(broken response not resent)",
        "es": "  ! JSON cortado por el limite de tokens: reintentando mas corto "
              "(respuesta rota no reenviada)"},
    "log_unreadable": {
        "fr": "  ! reponse illisible : %s",
        "en": "  ! unreadable response: %s",
        "es": "  ! respuesta ilegible: %s"},
    "log_errors_fix": {
        "fr": "  ! %d erreur(s), correction demandee :",
        "en": "  ! %d error(s), correction requested:",
        "es": "  ! %d error(es), correccion solicitada:"},
    "log_bullet": {
        "fr": "      - %s", "en": "      - %s", "es": "      - %s"},
    "log_section": {
        "fr": "  section %d/%d : %s (%s)",
        "en": "  section %d/%d: %s (%s)",
        "es": "  seccion %d/%d: %s (%s)"},
    "log_checksum_bad": {
        "fr": "    ! checksum invalide sur %s (fichier conserve)",
        "en": "    ! invalid checksum on %s (file kept)",
        "es": "    ! checksum invalido en %s (archivo conservado)"},
    "log_warn": {
        "fr": "    ! %s", "en": "    ! %s", "es": "    ! %s"},
    "log_written": {
        "fr": "      ecrit : %s",
        "en": "      written: %s",
        "es": "      escrito: %s"},
    "log_written2": {
        "fr": "    ecrit : %s",
        "en": "    written: %s",
        "es": "    escrito: %s"},
    "log_variant_skip": {
        "fr": "    ! variante %s ignoree : %s",
        "en": "    ! variant %s skipped: %s",
        "es": "    ! variante %s omitida: %s"},
    "log_src_checksum": {
        "fr": "  ! le preset source a un checksum invalide, on continue quand meme",
        "en": "  ! source preset has an invalid checksum, continuing anyway",
        "es": "  ! el preset original tiene checksum invalido, se continua igual"},
    "log_demande": {
        "fr": "demande : %s", "en": "request: %s", "es": "peticion: %s"},
    "log_provider_line": {
        "fr": "fournisseur : %s | modele : %s | recherche web : %s",
        "en": "provider: %s | model: %s | web search: %s",
        "es": "proveedor: %s | modelo: %s | busqueda web: %s"},
    "log_mode": {
        "fr": "mode : %s", "en": "mode: %s", "es": "modo: %s"},
    "log_calling": {
        "fr": "--- appel en cours, patiente... ---",
        "en": "--- calling, please wait... ---",
        "es": "--- llamando, espera... ---"},
    "log_structure": {
        "fr": "structure : %s", "en": "structure: %s", "es": "estructura: %s"},
    "log_struct_auto": {
        "fr": "detection auto", "en": "auto-detect", "es": "deteccion auto"},
    "log_struct_forced": {
        "fr": "imposee -> %s", "en": "forced -> %s", "es": "impuesta -> %s"},
    "log_response_recv": {
        "fr": "--- reponse recue, affichage... ---",
        "en": "--- response received, displaying... ---",
        "es": "--- respuesta recibida, mostrando... ---"},
    "log_error": {
        "fr": "\nERREUR : %s", "en": "\nERROR: %s", "es": "\nERROR: %s"},
    "log_config_unreadable": {
        "fr": "! config illisible : %s",
        "en": "! config unreadable: %s",
        "es": "! config ilegible: %s"},
    "log_refine_mode": {
        "fr": "mode : affinage de %s",
        "en": "mode: refining %s",
        "es": "modo: refinando %s"},

    "log_ws_off": {
        "fr": "! Recherche web coupee : le modele va deviner le rig de memoire.\n"
              "  Sans recherche, sur un morceau connu il se trompe souvent de rig.\n"
              "  A ne couper que si TU connais deja le rig et le decris toi-meme.",
        "en": "! Web search off: the model will guess the rig from memory.\n"
              "  Without search, it often gets the rig wrong on known songs.\n"
              "  Only turn off if YOU already know the rig and describe it yourself.",
        "es": "! Busqueda web desactivada: el modelo adivinara el equipo de memoria.\n"
              "  Sin busqueda, suele equivocarse de equipo en temas conocidos.\n"
              "  Desactivala solo si YA conoces el equipo y lo describes tu mismo."},

    # -- fenetre principale
    "app_title": {
        "fr": "GP-200 Studio \u2014 texte vers preset",
        "en": "GP-200 Studio \u2014 text-to-preset",
        "es": "GP-200 Studio \u2014 texto a preset"},
    "describe_title": {
        "fr": "Decris le son que tu veux",
        "en": "Describe the sound you want",
        "es": "Describe el sonido que quieres"},
    "describe_sub": {
        "fr": "Une chanson, un artiste, une ambiance. L'appli identifie le rig et "
              "genere 3 variantes par section.",
        "en": "A song, an artist, a mood. The app identifies the rig and generates "
              "3 variants per section.",
        "es": "Una cancion, un artista, un ambiente. La app identifica el equipo y "
              "genera 3 variantes por seccion."},
    "examples": {"fr": "Exemples :", "en": "Examples:", "es": "Ejemplos:"},
    "load_prst": {
        "fr": "Charger un .prst...",
        "en": "Load a .prst...",
        "es": "Cargar un .prst..."},
    "no_file": {"fr": "aucun fichier", "en": "no file", "es": "ningun archivo"},
    "loaded_file": {"fr": "charge : %s", "en": "loaded: %s", "es": "cargado: %s"},

    # -- options
    "options": {"fr": "Options", "en": "Options", "es": "Opciones"},
    "provider": {"fr": "Fournisseur :", "en": "Provider:", "es": "Proveedor:"},
    "model": {"fr": "Modele :", "en": "Model:", "es": "Modelo:"},
    "refresh": {"fr": "Actualiser", "en": "Refresh", "es": "Actualizar"},
    "output_dir_btn": {
        "fr": "Dossier de sortie",
        "en": "Output folder",
        "es": "Carpeta de salida"},
    "api_keys_btn": {
        "fr": "Cles API...",
        "en": "API keys...",
        "es": "Claves API..."},
    "language_label": {"fr": "Langue :", "en": "Language:", "es": "Idioma:"},
    "theme_toggle": {"fr": "\u263e/\u2600", "en": "\u263e/\u2600", "es": "\u263e/\u2600"},

    # -- structure
    "structure": {
        "fr": "Structure du morceau",
        "en": "Song structure",
        "es": "Estructura del tema"},
    "force": {"fr": "Forcer :", "en": "Force:", "es": "Forzar:"},
    "role_clean": {"fr": "clean", "en": "clean", "es": "limpio"},
    "role_crunch": {"fr": "crunch", "en": "crunch", "es": "crunch"},
    "role_disto": {"fr": "disto", "en": "dist", "es": "disto"},
    "role_lead": {"fr": "lead", "en": "lead", "es": "lead"},

    # -- actions
    "generate_button": {
        "fr": "Generer les presets",
        "en": "Generate presets",
        "es": "Generar presets"},
    "refine_button": {
        "fr": "Affiner le preset",
        "en": "Refine preset",
        "es": "Refinar preset"},
    "live_ready_button": {
        "fr": "\U0001f3a4 Optimiser pour concert",
        "en": "\U0001f3a4 Optimize for live",
        "es": "\U0001f3a4 Optimizar para directo"},
    "live_no_preset": {
        "fr": "Charge d'abord un fichier .prst a optimiser pour le live.",
        "en": "Load a .prst file first to optimize for live.",
        "es": "Primero carga un archivo .prst para optimizar para directo."},

    # -- harmonisation setlist
    "setlist_button": {
        "fr": "\U0001f3b5 Harmoniser setlist",
        "en": "\U0001f3b5 Harmonize setlist",
        "es": "\U0001f3b5 Armonizar setlist"},
    "setlist_title": {
        "fr": "Harmonisation de setlist",
        "en": "Setlist harmonization",
        "es": "Armonizacion de setlist"},
    "setlist_add": {
        "fr": "Ajouter des presets",
        "en": "Add presets",
        "es": "Anadir presets"},
    "setlist_remove": {
        "fr": "Retirer",
        "en": "Remove",
        "es": "Quitar"},
    "setlist_clear": {
        "fr": "Tout vider",
        "en": "Clear all",
        "es": "Vaciar todo"},
    "setlist_analyze": {
        "fr": "Analyser",
        "en": "Analyze",
        "es": "Analizar"},
    "setlist_apply": {
        "fr": "Appliquer",
        "en": "Apply",
        "es": "Aplicar"},
    "setlist_close": {
        "fr": "Fermer",
        "en": "Close",
        "es": "Cerrar"},
    "setlist_select": {
        "fr": "Selectionner les presets (.prst)",
        "en": "Select presets (.prst)",
        "es": "Seleccionar presets (.prst)"},
    "setlist_loaded": {
        "fr": "Presets charges",
        "en": "Loaded presets",
        "es": "Presets cargados"},
    "setlist_results": {
        "fr": "Volumes suggeres (ajustables)",
        "en": "Suggested volumes (adjustable)",
        "es": "Volumenes sugeridos (ajustables)"},
    "setlist_col_name": {
        "fr": "Preset", "en": "Preset", "es": "Preset"},
    "setlist_col_amp": {
        "fr": "Ampli", "en": "Amp", "es": "Ampli"},
    "setlist_col_current": {
        "fr": "Actuel", "en": "Current", "es": "Actual"},
    "setlist_col_suggested": {
        "fr": "Suggere (slider)", "en": "Suggested (slider)", "es": "Sugerido (slider)"},
    "setlist_count": {
        "fr": "%d preset(s) charge(s)",
        "en": "%d preset(s) loaded",
        "es": "%d preset(s) cargado(s)"},
    "setlist_empty": {
        "fr": "Ajoute d'abord des presets a analyser.",
        "en": "Add presets to analyze first.",
        "es": "Primero anade presets para analizar."},
    "setlist_error": {
        "fr": "Erreur : %s", "en": "Error: %s", "es": "Error: %s"},
    "setlist_analyzed": {
        "fr": "%d preset(s) analyse(s) - ajuste les sliders puis clique Appliquer",
        "en": "%d preset(s) analyzed - adjust sliders then click Apply",
        "es": "%d preset(s) analizado(s) - ajusta los sliders y haz clic en Aplicar"},
    "setlist_done": {
        "fr": "%d preset(s) harmonise(s) dans :\n%s",
        "en": "%d preset(s) harmonized to:\n%s",
        "es": "%d preset(s) armonizado(s) en:\n%s"},

    "working": {"fr": "Travail en cours...", "en": "Working...", "es": "Procesando..."},

    # -- usage
    "usage": {"fr": "Usage API", "en": "API usage", "es": "Uso de API"},
    "reset_usage": {
        "fr": "Remettre a zero",
        "en": "Reset",
        "es": "Reiniciar"},
    "open_folder": {
        "fr": "Ouvrir le dossier",
        "en": "Open folder",
        "es": "Abrir carpeta"},

    # -- resultat + menu contextuel
    "result": {"fr": "Resultat", "en": "Result", "es": "Resultado"},
    "copy": {"fr": "Copier", "en": "Copy", "es": "Copiar"},
    "copy_all": {
        "fr": "Tout copier",
        "en": "Copy all",
        "es": "Copiar todo"},
    "select_all": {
        "fr": "Tout selectionner",
        "en": "Select all",
        "es": "Seleccionar todo"},

    # -- messages
    "msg_empty_title": {"fr": "Vide", "en": "Empty", "es": "Vacio"},
    "msg_empty": {
        "fr": "Decris le son que tu veux.",
        "en": "Describe the sound you want.",
        "es": "Describe el sonido que quieres."},
    "msg_no_preset_title": {"fr": "Preset", "en": "Preset", "es": "Preset"},
    "msg_no_preset": {
        "fr": "Charge d'abord un fichier .prst.",
        "en": "Load a .prst file first.",
        "es": "Carga primero un archivo .prst."},
    "msg_no_key_title": {"fr": "Cle API", "en": "API key", "es": "Clave API"},
    "msg_no_key": {
        "fr": "Configure d'abord la cle API de ce fournisseur (bouton \u00ab Cles API \u00bb).",
        "en": "Set this provider's API key first (\u00ab API keys \u00bb button).",
        "es": "Configura primero la clave API de este proveedor (boton \u00ab Claves API \u00bb)."},
    "msg_done_title": {"fr": "Termine", "en": "Done", "es": "Terminado"},
    "msg_fail_title": {"fr": "Echec", "en": "Failed", "es": "Error"},
    "msg_read_fail": {
        "fr": "Lecture impossible",
        "en": "Cannot read",
        "es": "No se puede leer"},

    # -- dialogue cles API
    "keys_title": {
        "fr": "Configuration des cles API",
        "en": "API keys setup",
        "es": "Configuracion de claves API"},
    "keys_intro": {
        "fr": "Colle tes cles API. Elles sont chiffrees et liees a ta session "
              "Windows : illisibles depuis un autre compte ou un autre PC.",
        "en": "Paste your API keys. They are encrypted and tied to your Windows "
              "session: unreadable from another account or PC.",
        "es": "Pega tus claves API. Se cifran y se vinculan a tu sesion de Windows: "
              "ilegibles desde otra cuenta u otro PC."},
    "keys_claude": {"fr": "Cle Claude (Anthropic) :",
                    "en": "Claude (Anthropic) key:",
                    "es": "Clave Claude (Anthropic):"},
    "keys_gemini": {"fr": "Cle Gemini (Google) :",
                    "en": "Gemini (Google) key:",
                    "es": "Clave Gemini (Google):"},
    "keys_show": {"fr": "Afficher", "en": "Show", "es": "Mostrar"},
    "keys_save": {"fr": "Enregistrer", "en": "Save", "es": "Guardar"},
    "keys_cancel": {"fr": "Annuler", "en": "Cancel", "es": "Cancelar"},
    "keys_saved": {
        "fr": "Cles enregistrees.",
        "en": "Keys saved.",
        "es": "Claves guardadas."},
    "keys_at_least_one": {
        "fr": "Renseigne au moins une cle pour continuer.",
        "en": "Enter at least one key to continue.",
        "es": "Introduce al menos una clave para continuar."},

    # -- premier lancement : langue
    "welcome_lang_title": {
        "fr": "Bienvenue \u2014 choix de la langue",
        "en": "Welcome \u2014 language",
        "es": "Bienvenido \u2014 idioma"},
    "welcome_lang_prompt": {
        "fr": "Choisis la langue de l'interface (modifiable ensuite dans les options) :",
        "en": "Choose the interface language (changeable later in options):",
        "es": "Elige el idioma de la interfaz (modificable luego en opciones):"},
    "ok": {"fr": "OK", "en": "OK", "es": "OK"},}

_current = {"lang": DEFAULT_LANG}


def set_lang(lang):
    _current["lang"] = lang if lang in LANGS else DEFAULT_LANG


def get_lang():
    return _current["lang"]


def provider_label(prov):
    """Label traduit d'un fournisseur (gemini/anthropic/perplexity)."""
    return T("prov_" + prov)


def T(key, *args, **kwargs):
    """Traduit une clef. args/kwargs sont passes a % ou .format selon le besoin."""
    entry = _STRINGS.get(key)
    if entry is None:
        return key
    s = entry.get(_current["lang"]) or entry.get(DEFAULT_LANG) or key
    if args:
        try:
            return s % args
        except (TypeError, ValueError):
            return s
    if kwargs:
        try:
            return s.format(**kwargs)
        except (KeyError, IndexError, ValueError):
            return s
    return s