#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Confronte data/*.json (extraction firmware) a algorithm.xml (source Valeton)."""
import json, re, sys, collections
import xml.etree.ElementTree as ET

XML = sys.argv[1] if len(sys.argv) > 1 else "algorithm.xml"
PARAM_TAGS = ("Knob", "Switch", "Menu", "Combox", "Slider")

root = ET.parse(XML).getroot()

# ---------------------------------------------------------------- parse XML
xml_algs = {}          # (cat, id) -> {name, params, catalogs}
catalog_members = collections.defaultdict(set)   # catalog -> {(cat,id)}

for cat_el in root.findall("Catalog"):
    cname = cat_el.get("Name").strip()
    for alg in cat_el.findall("Alg"):
        code = int(alg.get("Code"))
        cat, mid = code >> 24, code & 0xFFFFFF
        params = []
        for ch in alg:
            if ch.tag not in PARAM_TAGS:
                continue
            g = lambda k: ch.get(k) or ch.get(k.lower()) or ch.get(k.capitalize())

            def num(v):
                """Certains attributs sont textuels : '-25 Cents', '1/4 Note'.
                On extrait le premier nombre, sinon None."""
                if v is None:
                    return None
                m = re.match(r"\s*(-?\d+(?:\.\d+)?)", str(v))
                return float(m.group(1)) if m else None

            params.append({
                "name": (g("Name") or "").strip(),
                "tag": ch.tag,
                "idx": num(g("idx")),
                "ID": num(g("ID")),
                "default": num(g("default")),
                "default_raw": g("default"),
                "min": num(g("Dmin")),
                "max": num(g("Dmax")),
            })
        key = (cat, mid)
        catalog_members[cname].add(key)
        if key not in xml_algs:
            xml_algs[key] = {"name": alg.get("Name").strip(), "params": params,
                             "module": alg.get("Module"), "catalogs": {cname}}
        else:
            xml_algs[key]["catalogs"].add(cname)

if not xml_algs:
    sys.exit("ERREUR : %r ne contient aucun <Alg>. Ce script attend "
             "algorithm.xml (pas description_en.xml, qui utilise <Algorithm> "
             "et se traite avec make_descriptions.py)." % XML)

print("=" * 74)
print("algorithm.xml : %d Alg uniques, %d catalogues" % (len(xml_algs), len(catalog_members)))
print("=" * 74)

# ---------------------------------------------------------------- nos tables
models = json.load(open("data/gp200_models_all.json", encoding="utf-8"))
cabs = json.load(open("data/gp200_cabs.json", encoding="utf-8"))
ours = {}
for m in models:
    ours[(m["cat"], m["id"])] = {"name": m["name"], "params": m["params"]}
for c in cabs:
    if not c["user_slot"]:
        ours[(10, c["model_id"])] = {"name": c["name"], "params": None}

# ---------------------------------------------------------------- 1. SLOT_ACCEPTS
print("\n### 1. SLOT_ACCEPTS — ce que chaque module accepte VRAIMENT")
sys.path.insert(0, ".")
from gp200lib import SLOT_ACCEPTS
for cname in ["PRE", "WAH", "DST", "AMP", "NR", "CAB", "EQ", "MOD", "DLY", "RVB", "VOL"]:
    if cname not in catalog_members:
        print("  %-4s : catalogue ABSENT du XML (?)" % cname)
        continue
    real = sorted({k[0] for k in catalog_members[cname]})
    ours_a = SLOT_ACCEPTS.get(cname, [])
    faux_pos = [c for c in ours_a if c not in real]
    manque = [c for c in real if c not in ours_a]
    verdict = "OK" if not faux_pos and not manque else ""
    if faux_pos:
        verdict += "cat %s INVENTEE(S) " % faux_pos
    if manque:
        verdict += "cat %s MANQUANTE(S)" % manque
    print("  %-4s : nous=%-12s officiel=%-12s  %s"
          % (cname, ours_a, real, verdict))

# ---------------------------------------------------------------- 2. noms
print("\n### 2. NOMS")
common = set(xml_algs) & set(ours)
mismatch = [(k, ours[k]["name"], xml_algs[k]["name"]) for k in common
            if ours[k]["name"] != xml_algs[k]["name"]]
print("  communs %d | identiques %d | divergents %d"
      % (len(common), len(common) - len(mismatch), len(mismatch)))
from gp200lib import _norm
for k, a, b in sorted(mismatch):
    if k[0] == 15:
        # Le XML nomme les 10 SnapTone a l'identique ("SnapTone"), ce que la
        # garde anti-collision de Tables() refuse. Le suffixe est DE NOUS.
        note = "VOULU (suffixe local, le XML les nomme tous 'SnapTone')"
    elif _norm(a) != _norm(b):
        note = "BLOQUANT"
    else:
        note = "cosmetique (_norm absorbe)"
    print("    cat%-2d id=%-4d nous=%-18s xml=%-18s  %s" % (k[0], k[1], a, b, note))

only_xml = set(xml_algs) - set(ours)
only_us = set(ours) - set(xml_algs)
print("  dans le XML, absents de nos tables : %d" % len(only_xml))
byc = collections.Counter(k[0] for k in only_xml)
for c in sorted(byc):
    ex = sorted(k for k in only_xml if k[0] == c)[:3]
    print("     cat%-2d : %3d entrees  ex. %s" % (c, byc[c], [xml_algs[k]["name"] for k in ex]))
print("  dans nos tables, absents du XML   : %d %s"
      % (len(only_us), sorted(only_us)[:5] if only_us else ""))

# ---------------------------------------------------------------- 3. params
print("\n### 3. PARAMETRES (nombre, noms, mapping slot)")
n_ok = n_count = n_name = n_slot = n_range = 0
details = []
for k in sorted(common):
    if ours[k]["params"] is None:
        continue                      # CAB : bloc commun, traite a part
    op = ours[k]["params"]
    xp = xml_algs[k]["params"]
    nm = xml_algs[k]["name"]
    probs = []
    if len(op) != len(xp):
        probs.append("nb %d vs %d (xml: %s)"
                     % (len(op), len(xp), [p["name"] for p in xp]))
        n_count += 1
    else:
        for a, b in zip(op, xp):
            if _norm(a["name"]) != _norm(b["name"]):
                probs.append("nom %r vs %r" % (a["name"], b["name"])); n_name += 1
            if b["ID"] is not None and a["slot"] != int(b["ID"]):
                probs.append("slot %s: %d vs ID=%d" % (a["name"], a["slot"], int(b["ID"])))
                n_slot += 1
            if b["min"] is not None and (a["min"], a["max"]) != (b["min"], b["max"]):
                probs.append("bornes %s: [%g,%g] vs [%g,%g]"
                             % (a["name"], a["min"], a["max"], b["min"], b["max"]))
                n_range += 1
    if probs:
        details.append((k, nm, probs))
    else:
        n_ok += 1

print("  modeles au parametrage EXACT : %d" % n_ok)
print("  divergences : nombre=%d noms=%d slots=%d bornes=%d"
      % (n_count, n_name, n_slot, n_range))
for k, nm, probs in details[:25]:
    print("    cat%-2d id=%-4d %-16s" % (k[0], k[1], nm))
    for p in probs[:4]:
        print("        - %s" % p)
if len(details) > 25:
    print("    ... et %d autres modeles" % (len(details) - 25))

json.dump({"%d,%d" % k: {"name": v["name"], "params": v["params"],
                         "catalogs": sorted(v["catalogs"])}
           for k, v in xml_algs.items()},
          open("xml_parsed.json", "w", encoding="utf-8"), indent=1,
          ensure_ascii=False)
print("\n-> xml_parsed.json ecrit (%d entrees)" % len(xml_algs))
