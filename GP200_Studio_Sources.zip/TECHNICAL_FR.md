# GP-200 Studio — Documentation technique

## Presentation

GP-200 Studio est un generateur de presets pour le **Valeton GP-200**.
L'utilisateur decrit un son en texte libre (ex. *"crunch blues chaud a la SRV"*),
et l'application appelle une API d'IA (Gemini, Claude, OpenAI ou Perplexity) pour
produire des fichiers `.prst` prets a charger sur la carte SD du GP-200.

Le projet est ecrit en **Python 3 / Tkinter**, sans framework lourd et **sans
aucune dependance externe** : bibliotheque standard uniquement (`tkinter`,
`urllib`, `json`, `struct`). Il peut tourner en script
(`python gp200_studio.py`) ou etre compile en `.exe` Windows autonome avec
PyInstaller (`build_exe.bat`).


## Arborescence du projet

```
GP200_Studio/
|
|-- gp200_studio.py          Interface graphique Tkinter (point d'entree)
|-- gp200_theme.py           Systeme de design : jetons, theme ttk, echelle ecran
|-- gp200_ui.py              Composants graphiques dessines au Canvas
|-- design_preview.py        Maquette autonome du design (donnees fictives)
|
|-- gp200_agent.py           Moteur IA : appels API, prompt, validation, ecriture .prst
|-- gp200lib.py              Coeur binaire : encodage/decodage du format .prst (1224 octets)
|-- gp200_setlist.py         Harmonisation des volumes d'une setlist
|-- gp200_i18n.py            Traductions (fr/en/es), version, constantes UI
|-- gp200_secrets.py         Chiffrement des cles API via DPAPI (Windows)
|-- gp200_validate.py        Harnais de validation firmware (outil de dev)
|
|-- data/                    Tables extraites du firmware GP-200 v1.8.0
|   |-- gp200_models_all.json   216 modeles (amplis, effets, cabs) avec parametres et plages
|   |-- gp200_cabs.json         90 cabs/IRs
|   |-- gp200_factory_presets.json  128 presets usine (reference)
|   |-- gp200_descriptions.json     Descriptions textuelles des modeles pour le prompt IA
|   |-- models_amp.json, models_dst.json, ...   Tables detaillees par categorie
|
|-- template.prst            Preset vide de reference (1224 octets), base de l'encodage
|-- config.example.json      Exemple de configuration (a copier en config.json)
|-- GP200_Studio.bat         Lanceur Windows (double-clic)
|-- build_exe.bat            Script de compilation PyInstaller
|
|-- make_descriptions.py     Genere les descriptions textuelles des modeles (outil de dev)
|-- patch_data.py            Correctifs sur les tables firmware (outil de dev)
|-- bump_version.py          Incremente APP_VERSION avant compilation (outil de dev)
|-- xml_diff.py              Compare deux exports XML du GP-200 (outil de dev)
|
|-- CHANGELOG.md             Historique des modifications
|-- .gitignore               Ignore config.json, .venv/, build/, dist/
```

### Separation stricte moteur / presentation

La couche graphique (`gp200_studio.py`, `gp200_theme.py`, `gp200_ui.py`) et le
moteur (`gp200_agent.py`, `gp200lib.py`, `gp200_setlist.py`, `gp200_secrets.py`)
sont independants :

* `gp200_theme.py` et `gp200_ui.py` **n'importent rien du moteur**. Ils ne savent
  pas ce qu'est un `.prst`. Ils recoivent des dictionnaires et emettent des
  callbacks.
* Le moteur n'importe rien de la couche graphique.

Consequence pratique : on peut refondre entierement l'interface sans risque de
regression sur la generation, et `design_preview.py` se lance sans cle API, sans
reseau et sans pouvoir ecrire le moindre fichier.


## Interface graphique

### `gp200_theme.py` — systeme de design

Aucune logique metier. Expose :

* **`TOK`** : jetons de design. Couleurs (fond, encres, filets, accent cyan,
  etats) et geometrie (rayons, espacements, tailles de carte, largeur de la
  colonne laterale).
* **`CAT`** / **`SLOT_CAT`** : les 11 modules regroupes en trois familles.
  La couleur n'est pas decorative, elle dit ou l'on se trouve dans la chaine :

  | Famille | Modules | Role |
  |---|---|---|
  | `GEN` — bleu glacier | `PRE`, `DST`, `AMP` | fabrique le son |
  | `CAB` — vert | `NR`, `CAB`, `EQ` | met en forme |
  | `FX` — mauve | `WAH`, `MOD`, `DLY`, `RVB`, `VOL` | colore |

* **`apply_theme(root, scale=None)`** : recable integralement le theme ttk sur la
  palette. Base sur `clam`, le seul theme ttk entierement recolorable sur les
  trois OS. Renvoie le dictionnaire `FONT`.
* **`compute_scale(root)`** / **`scale_tokens(s)`** / **`UI_SCALE`** : facteur
  d'echelle deduit de la resolution de l'ecran, borne a 0,85 - 1,30. La mise a
  l'echelle repart toujours d'une copie de reference des jetons, jamais du
  resultat precedent : deux appels a `apply_theme()` ne composent pas leurs
  facteurs.
* **Utilitaires couleur** : `mix`, `lighten`, `darken`, `ramp`, `luma`.
* **Geometrie** : `round_rect_points()` echantillonne les quatre quarts de cercle
  (rayon exact, contrairement a l'astuce `smooth=True` qui produit une spline
  approximative) ; `corner_inset()` donne le retrait horizontal a une hauteur
  donnee dans la zone d'un coin, ce qui permet de decouper un degrade ligne par
  ligne sur une forme arrondie.
* **`sil(texte)`** : Tkinter n'a pas de `letter-spacing`. L'interlettrage des
  libelles serigraphies est insere dans la chaine. Reserve aux libelles courts.

Typographie : trois roles, trois familles avec repli automatique.
`Bahnschrift Condensed` (livree avec Windows 10/11) pour les titres et la
serigraphie, `Segoe UI` pour le texte courant, `Cascadia Mono` / `Consolas` pour
les valeurs de parametres — chasse fixe, pour que les chiffres ne dansent pas
quand ils changent.

### `gp200_ui.py` — composants

Widgets dessines au Canvas, en Tkinter pur. Aucune logique metier.

| Composant | Role |
|---|---|
| `SignalRack` | Les 11 modules et leur cordon. `set_slots()`, `set_progress(k)`, `start_flow()`, `select(i)`, `selected()` |
| `ModuleInspector` | Tous les parametres du module choisi. `set_module(mod, pos)` |
| `PresetList` | Liste dense scrollable, survol et selection pleine largeur |
| `GlowButton` | Action primaire, halo cyan, etat `set_busy()` respirant. Expose `configure(text=, state=)` pour rester compatible avec un `ttk.Button` |
| `Well` | Creux a coins arrondis qui heberge un `Text` ou une `Entry` |
| `VMeter` | Bargraph a segments avec repere de cible (`patch_vol`) |
| `Chip`, `Led`, `Silk`, `GradientStrip` | Pastille de valeur, temoin lumineux, libelle serigraphie, bandeau |

Format attendu par `SignalRack.set_slots()` — directement derivable de
`decode_prst()`, dont la sortie a deja cette forme :

```python
[{"slot": "AMP", "model": "Mess2C+ 2", "on": True,
  "params": {"Gain": 65, "Presence": 70, "Volume": 75}}, ...]
```

### Ce que Tkinter ne sait pas faire, et comment c'est contourne

| Manque | Solution |
|---|---|
| Coins arrondis | Polygone echantillonne sur les quarts de cercle (`round_rect_points`) |
| Degrades | Trace ligne par ligne, chaque ligne rentree de la bonne quantite dans la zone des coins (`corner_inset`) |
| Transparence / halo | Melange manuel vers la couleur de fond, couche par couche (`glow_round_rect`) |
| `letter-spacing` | Espacement insere dans la chaine (`sil()`) |
| `Text` a coins arrondis | Creux dessine au Canvas + `create_window` (`Well`) |
| Ligne de liste stylee | `Canvas` plutot que `Listbox` (`PresetList`) |

**Limite acceptee** : pas d'anticrenelage. Les arrondis et les halos presentent un
leger escalier en diagonale, invisible a 100 % de zoom. C'est le plafond de
Tkinter.

### Comportement adaptatif du rack

Le rack **prend la mesure de la place disponible** au lieu de s'imposer une
taille. Priorite absolue : les 11 modules sur **une seule ligne** — une chaine de
signal qui serpente sur deux rangs n'est plus une chaine.

1. Calcul de la largeur de carte qui fait tenir les 11 modules de bout en bout.
   Deux passes : gouttiere confortable d'abord (on doit voir le cordon), puis
   resserree avant de renoncer.
2. Si l'echelle resultante descend sous 0,46, repli sur plusieurs rangs en
   serpentin, avec defilement et hauteur plafonnee a deux rangs visibles.

Le rack et l'inspecteur **demandent exactement la hauteur de leur contenu**
(`configure(height=...)`, avec un garde-fou de 3 px contre la boucle
`Configure -> resize -> Configure`). Le bloc Resultat/Journal, seul en `expand`,
absorbe tout le reste.

### Pieges Tkinter documentes dans le code

* **`self._w` est reserve** : `Misc._w` contient le chemin Tcl du widget. Les
  dimensions internes des composants sont donc `_cw` / `_ch`.
* **Ordre de `pack()`** : un conteneur en `expand=True` declare avant un pied en
  `side="bottom"` absorbe toute la cavite. Le pied se packe en premier.
* **`ttk.Panedwindow`** fige son separateur d'apres la taille annoncee au premier
  calcul de geometrie, avant que les Canvas aient dessine leur contenu. Un
  empilage simple n'a pas ce defaut — c'est ce qui est utilise.


## Description des fichiers du moteur

### `gp200_studio.py` — interface

Point d'entree. Gere :
- Le premier lancement (choix de langue, saisie des cles API)
- L'interface complete (description, selection de provider/modele, detection de
  structure, mode generation et mode affinage)
- La visualisation de la chaine, l'inspecteur de module, la navigation dans les
  presets generes
- L'affichage des resultats (compte-rendu, journal detaille)
- Le suivi de consommation API

Depend de `gp200_agent`, `gp200lib`, `gp200_setlist`, `gp200_i18n`,
`gp200_secrets`, `gp200_theme`, `gp200_ui`.

Les libelles propres au design vivent dans un dictionnaire `_DTXT` local, avec la
fonction `DT(key, *args)` qui suit la langue courante. Motif : `gp200_i18n.py`
fait partie du moteur et reste inchange.

`_build()` doit rester **re-entrant** : `_retranslate()` detruit tous les enfants
et le rappelle. Aucun etat ne doit vivre ailleurs que dans `self.cfg` ou dans des
variables recreees par `_build()` — a l'exception de `self._gen`, la liste des
presets generes, explicitement preservee au changement de langue.

### `gp200_agent.py` — moteur IA

Le coeur de la generation. Chaine complete :
1. Construction du prompt systeme (catalogue compact, regles de formatage)
2. Appel API (Gemini, Claude, OpenAI ou Perplexity) via `urllib` (stdlib)
3. Parsing de la reponse JSON
4. Validation contre les tables firmware (noms de modeles, plages de parametres)
5. Boucle d'auto-correction si le modele hallucine un nom de modele
6. Encodage binaire et ecriture des fichiers `.prst`

Expose aussi `refine_live()` (optimisation concert) et `estimate_patch_vol()`
(estimation du volume d'un preset, utilisee par l'harmonisation de setlist).

### `gp200lib.py` — format binaire `.prst`

Reverse-engineere depuis le firmware V1.8.0. Gere :
- **`Tables`** : chargement du catalogue (modeles, cabs, parametres, plages)
- **`encode_prst(spec, tables)`** : dict JSON -> fichier `.prst` de 1224 octets
- **`decode_prst(path, tables)`** : fichier `.prst` -> dict JSON lisible
- Checksum, chaine d'effets (chain_order), slots de parametres

Points importants :
- Un modele est identifie par le couple `(model_id, category)`, pas l'id seul
- L'espace d'id est creux (pas un index sequentiel)
- 11 slots de modules : `NR`, `WAH`, `DST`, `AMP`, `CAB`, `MOD`, `DLY`, `RVB`,
  `EQ`, `VOL`, `PRE`

### `gp200_setlist.py` — harmonisation de setlist

`analyze_setlist(paths, tables)` decode une liste de presets et estime leur
volume via `estimate_patch_vol()`. `apply_setlist(entries, output_dir, log=None)`
reecrit les fichiers harmonises dans un dossier horodate. Seul l'octet
`patch_vol` change, et le checksum est recalcule. Aucun appel API.

### `gp200_i18n.py` — internationalisation

Dictionnaire unique `STRINGS` avec toutes les chaines du moteur en francais,
anglais et espagnol. Contient aussi `APP_VERSION`, les labels `PROVIDERS` et la
fonction `T(key, *args)`.

### `gp200_secrets.py` — chiffrement des cles API

Utilise DPAPI (Windows) pour chiffrer les cles API dans `config.json`.
Hors Windows, un encodage base64 reversible sert de repli.
Format : `"dpapi:..."` (chiffre) ou `"plain:..."` (encode).
Les anciennes cles en clair sont lues telles quelles (retrocompatibilite).


## Configuration

Copier `config.example.json` en `config.json` et renseigner au minimum
une cle API :

```json
{
  "provider": "gemini",
  "api_key_gemini": "AIza...",
  "api_key_anthropic": "",
  "api_key_openai": "",
  "api_key_perplexity": "",
  "model": "gemini-3.5-flash",
  "web_search": true,
  "output_dir": "",
  "budget_usd": 6.0
}
```

- **`provider`** : `gemini` (gratuit), `anthropic`, `openai`, `perplexity`
- **`web_search`** : recherche web pour identifier le vrai rig (poste le plus cher en tokens)
- **`output_dir`** : dossier de sortie des `.prst` (vide = `Documents\GP200_Presets`)
- **`budget_usd`** : plafond de depense estimee (Anthropic uniquement)

> La cle `"theme"` des versions precedentes est ignoree : l'interface n'a plus
> qu'une palette sombre. Sa presence dans un `config.json` existant ne provoque
> aucune erreur, aucune migration n'est necessaire.


## Lancement

```bash
# En script
python gp200_studio.py

# Sous Windows (double-clic)
GP200_Studio.bat

# Selftest (sans interface)
python gp200_studio.py --selftest

# Maquette du design seule (donnees fictives, aucun appel API)
python design_preview.py
```

`--selftest` doit repondre :
`SELFTEST OK : 216 modeles, 90 cabs, encodage 1224 o`


## Compilation en .exe

```bash
build_exe.bat
```

Produit `dist/GP200_Studio.exe`. Le script :
1. Verifie la presence de tous les fichiers requis, y compris `gp200_theme.py`
   et `gp200_ui.py`
2. Cree un venv et installe PyInstaller
3. Compile en `--onefile --windowed`, avec `gp200_theme` et `gp200_ui` en
   `--hidden-import`
4. Lance le selftest sur l'exe produit

Aucune dependance graphique tierce n'est installee : le theme est integre.


## Structure de la generation

L'IA genere entre 3 et 9 presets par demande, organises en **sections** :
- Mode **auto** : l'IA detecte la structure (ex. 3 variantes d'un son, ou
  clean/crunch/disto pour un artiste)
- Mode **force** : l'utilisateur impose les roles (`clean`, `crunch`, `disto`, `lead`)

Chaque preset est un dict JSON avec la structure :
```json
{
  "name": "Blues SRV",
  "modules": {
    "AMP": {"model": "TX Star", "on": true, "params": {"Gain": 65, "Bass": 55}},
    "CAB": {"model": "4x12 Brit G75", "on": true},
    "RVB": {"model": "Spring 63", "on": true, "params": {"Decay": 40}}
  }
}
```

Le moteur valide chaque nom de modele et chaque valeur de parametre contre
les tables firmware, et corrige automatiquement les hallucinations.

L'interface recoit ce resultat sous la forme d'une liste
`(chemin, section, variante)` et en construit la liste navigable de la colonne de
gauche, sans rien demander de plus au moteur.


## Mode affinage (refine)

Permet de charger un `.prst` existant, de le decoder, puis de demander une
modification en texte libre (*"plus de gain, moins de reverb"*). L'IA recoit
le preset decode et produit une version modifiee. Les changements reels
(compares par diff sur les fichiers decodes, pas declares par le modele) sont
affiches a l'utilisateur.

La chaine du preset charge est affichee des l'ouverture du fichier, avant tout
appel API.


## Contribution

Le projet est libre. Points d'entree pour contribuer :

- **Nouvelles langues** : ajouter une entree dans `LANGS` et les traductions dans
  `STRINGS` (`gp200_i18n.py`), plus le dictionnaire `_DTXT` de `gp200_studio.py`
  pour les libelles propres au design
- **Nouveaux providers** : ajouter une entree dans `PROVIDERS` (`gp200_agent.py`)
  et l'appel API correspondant
- **Mise a jour firmware** : si Valeton publie un nouveau firmware avec de
  nouveaux modeles, extraire les tables et les ajouter dans `data/`
- **Apparence** : tout passe par `gp200_theme.py`. Changer une couleur ou un
  espacement se fait dans `TOK`, sans toucher a un seul composant. Un mode clair
  se ferait en ajoutant une seconde palette.
- **Nouveaux composants** : `gp200_ui.py` ne depend que de `gp200_theme`.
  Utiliser `design_preview.py` pour iterer sans lancer l'application complete.
