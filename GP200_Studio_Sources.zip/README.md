# GP-200 Studio

Generateur de presets pour le multi-effets **Valeton GP-200**, pilote par IA.

Tu decris un son en francais courant — *"crunch blues chaud a la SRV"*,
*"Master of Puppets, son rythmique album"* — l'application interroge une IA,
valide le resultat contre les tables extraites du firmware, et ecrit des fichiers
`.prst` prets a copier sur la carte SD de l'appareil.

**Python 3 + Tkinter. Aucune dependance externe.**

---

## Demarrage rapide

```bash
# 1. Recuperer une cle API (Gemini est gratuit, sans carte bancaire)
#    https://aistudio.google.com/app/apikey

# 2. Configurer
cp config.example.json config.json     # puis y coller la cle

# 3. Lancer
python gp200_studio.py
```

Sous Windows : double-cliquer sur `GP200_Studio.bat`.
Pour fabriquer un `.exe` autonome : `build_exe.bat`.

Voir **[GUIDE_FR.md](GUIDE_FR.md)** pour le guide complet
(*[English](GUIDE_EN.md)* · *[Espanol](GUIDE_ES.md)*).

---

## Ce que ca fait

**Genere une setlist coherente, pas un preset isole.** L'IA determine d'abord
combien de sons *differents* le morceau demande, puis produit 3 variantes par
son : 3, 6 ou 9 fichiers, ranges par section.

**Affine un preset existant.** Charge un `.prst`, decris ce que tu veux changer
en clair. Le diff affiche est calcule sur les fichiers decodes — pas recopie de
ce que le modele pretend avoir fait.

**Optimise pour le concert.** Adapte un preset fait a la maison au jeu a fort
volume : gain reduit, mix reverb/delay reduits, coupe-haut anti-fizz, leger boost
de mediums.

**Harmonise une setlist.** Egalise les volumes de 10 ou 15 presets entre eux,
sans appel API. Seul l'octet de volume change.

**Visualise la chaine de signal.** Les 11 modules sur une ligne, dans l'ordre
reel, relies par un cordon. Un clic sur un module montre tous ses reglages.

---

## Ce qui rend la generation fiable

Une IA qui invente un nom de modele est un probleme classique. Ici il est traite
structurellement, pas par la confiance :

* **Le modele ne voit jamais les `slot`.** C'est `gp200lib` qui place les
  valeurs aux bons offsets. Une hallucination sur un slot est donc *impossible*.
* **Tout nom est valide contre les tables du firmware.** Un nom inexistant ne
  produit pas de fichier : l'erreur repart au modele avec les noms proches,
  jusqu'a `max_retries`.
* **Les tables ont deux sources independantes.** L'extraction du firmware V1.8.0
  a ete confrontee a `algorithm.xml`, le fichier dont l'editeur officiel Valeton
  se sert pour afficher ses menus. Verdict : 0 modele invente, 0 slot faux,
  0 borne fausse. Voir [CHANGELOG.md](CHANGELOG.md).

---

## Limite a connaitre

**Aucun preset n'a jamais ete importe dans un GP-200 physique.** Le format est
verifie par round-trip sur des patchs reels et confronte a l'editeur officiel,
mais le comportement de l'appareil a l'import reste a confirmer.

Les tables decrivent le **firmware V1.8.0**. Valeton apparie strictement firmware
et editeur, et la v1.8.0 ajoute des effets : sur une unite en 1.6.3 ou 1.7.0 le
catalogue est different.

---

## Fournisseurs d'IA supportes

| Fournisseur | Cout | Carte bancaire |
|---|---|---|
| **Google Gemini** (defaut) | offre gratuite | non requise |
| Anthropic Claude | ~0,03 a 0,25 $ / generation | requise |
| OpenAI | payant a l'usage | requise |
| Perplexity | payant a l'usage (recherche incluse) | requise |

La cle est stockee localement, chiffree sous Windows via DPAPI, et n'est envoyee
qu'au fournisseur choisi. `config.json` est dans le `.gitignore`.

---

## Documentation

| Fichier | Contenu |
|---|---|
| [GUIDE_FR.md](GUIDE_FR.md) · [EN](GUIDE_EN.md) · [ES](GUIDE_ES.md) | Guide d'utilisation |
| [TECHNICAL_FR.md](TECHNICAL_FR.md) · [EN](TECHNICAL_EN.md) · [ES](TECHNICAL_ES.md) | Architecture, format binaire, contribution |
| [README_APP.md](README_APP.md) | Installation detaillee, compilation, couts reels |
| [CHANGELOG.md](CHANGELOG.md) | Historique, dont le travail de reverse engineering |

---

## Architecture en une image

```
gp200_studio.py     Interface          \
gp200_theme.py      Systeme de design   >  presentation
gp200_ui.py         Composants Canvas  /
---------------------------------------------------------
gp200_agent.py      Moteur IA          \
gp200lib.py         Format .prst        >  moteur
gp200_setlist.py    Harmonisation      /
gp200_secrets.py    Chiffrement des cles
gp200_i18n.py       Traductions (fr/en/es)
```

Les deux couches sont independantes : `gp200_theme.py` et `gp200_ui.py`
n'importent rien du moteur et ne savent pas ce qu'est un `.prst`. On peut refondre
l'interface sans risque de regression sur la generation.

```bash
python design_preview.py    # la maquette de l'interface, sans cle API ni reseau
python gp200_studio.py --selftest
# -> SELFTEST OK : 216 modeles, 90 cabs, encodage 1224 o
```

---

## Contribuer

Les points d'entree sont detailles dans [TECHNICAL_FR.md](TECHNICAL_FR.md).
En resume : les traductions vivent dans `gp200_i18n.py`, l'apparence entierement
dans les jetons `TOK` de `gp200_theme.py`, et l'ajout d'un fournisseur d'IA se
fait dans `PROVIDERS` (`gp200_agent.py`).

Les tests les plus utiles seraient ceux qu'on ne peut pas faire sans le materiel :
**si tu possedes un GP-200, importer un preset genere et rapporter ce qui se
passe** ferait avancer le projet plus que n'importe quel patch.

---

## Licence

> **A definir.** Aucun fichier `LICENSE` n'est encore present : en l'absence de
> licence explicite, le droit d'auteur par defaut s'applique et personne ne peut
> legalement reutiliser le code. Ajouter un `LICENSE` a la racine avant toute
> publication publique.
