# GP-200 Studio — Technical Documentation

## Overview

GP-200 Studio is a preset generator for the **Valeton GP-200** multi-effects
processor. The user describes a sound in plain text (e.g. *"warm bluesy crunch a
la SRV"*), and the application calls an AI API (Gemini, Claude, OpenAI or
Perplexity) to produce `.prst` files ready to load onto the GP-200's SD card.

The project is written in **Python 3 / Tkinter**, with no heavy framework and
**no external dependencies at all** — standard library only (`tkinter`, `urllib`,
`json`, `struct`). It can run as a script (`python gp200_studio.py`) or be
compiled into a standalone Windows `.exe` using PyInstaller (`build_exe.bat`).


## Project structure

```
GP200_Studio/
|
|-- gp200_studio.py          Tkinter GUI (entry point)
|-- gp200_theme.py           Design system: tokens, ttk theme, screen scaling
|-- gp200_ui.py              Canvas-drawn UI components
|-- design_preview.py        Standalone design mockup (fake data)
|
|-- gp200_agent.py           AI engine: API calls, prompt, validation, .prst writing
|-- gp200lib.py              Binary core: .prst format encoding/decoding (1224 bytes)
|-- gp200_setlist.py         Setlist volume harmonisation
|-- gp200_i18n.py            Translations (fr/en/es), version number, UI constants
|-- gp200_secrets.py         API key encryption via DPAPI (Windows)
|-- gp200_validate.py        Firmware validation harness (dev tool)
|
|-- data/                    Tables extracted from GP-200 firmware v1.8.0
|   |-- gp200_models_all.json   216 models (amps, effects, cabs) with parameters and ranges
|   |-- gp200_cabs.json         90 cabs/IRs
|   |-- gp200_factory_presets.json  128 factory presets (reference)
|   |-- gp200_descriptions.json     Text descriptions of models for the AI prompt
|   |-- models_amp.json, models_dst.json, ...   Detailed tables per category
|
|-- template.prst            Blank reference preset (1224 bytes), encoding base
|-- config.example.json      Configuration template (copy to config.json)
|-- GP200_Studio.bat         Windows launcher (double-click)
|-- build_exe.bat            PyInstaller build script
|
|-- make_descriptions.py     Generates text descriptions for models (dev tool)
|-- patch_data.py            Firmware table patches (dev tool)
|-- bump_version.py          Increments APP_VERSION before compilation (dev tool)
|-- xml_diff.py              Compares two GP-200 XML exports (dev tool)
|
|-- CHANGELOG.md             Change log
|-- .gitignore               Ignores config.json, .venv/, build/, dist/
```

### Strict engine / presentation separation

The UI layer (`gp200_studio.py`, `gp200_theme.py`, `gp200_ui.py`) and the engine
(`gp200_agent.py`, `gp200lib.py`, `gp200_setlist.py`, `gp200_secrets.py`) are
independent:

* `gp200_theme.py` and `gp200_ui.py` **import nothing from the engine**. They do
  not know what a `.prst` is. They receive dictionaries and emit callbacks.
* The engine imports nothing from the UI layer.

Practical consequence: the interface can be rebuilt entirely with no risk of
regression in generation, and `design_preview.py` runs with no API key, no
network access, and no ability to write a single file.


## User interface

### `gp200_theme.py` — design system

No business logic. Exposes:

* **`TOK`**: design tokens. Colours (background, inks, rules, cyan accent,
  states) and geometry (radii, spacing, card sizes, sidebar width).
* **`CAT`** / **`SLOT_CAT`**: the 11 modules grouped into three families. Colour
  is not decorative — it tells you where you are in the signal chain:

  | Family | Modules | Role |
  |---|---|---|
  | `GEN` — glacier blue | `PRE`, `DST`, `AMP` | makes the sound |
  | `CAB` — green | `NR`, `CAB`, `EQ` | shapes it |
  | `FX` — magenta | `WAH`, `MOD`, `DLY`, `RVB`, `VOL` | colours it |

* **`apply_theme(root, scale=None)`**: rewires the ttk theme onto the palette.
  Built on `clam`, the only ttk theme fully recolourable across all three OSes.
  Returns the `FONT` dictionary.
* **`compute_scale(root)`** / **`scale_tokens(s)`** / **`UI_SCALE`**: scale factor
  derived from screen resolution, clamped to 0.85 - 1.30. Scaling always restarts
  from a pristine copy of the tokens, never from the previous result: two calls to
  `apply_theme()` do not compound their factors.
* **Colour utilities**: `mix`, `lighten`, `darken`, `ramp`, `luma`.
* **Geometry**: `round_rect_points()` samples the four quarter-circles (exact
  radius, unlike the `smooth=True` trick which produces an approximate spline);
  `corner_inset()` gives the horizontal inset at a given height within a corner,
  which is what makes it possible to slice a gradient line by line over a rounded
  shape.
* **`sil(text)`**: Tkinter has no `letter-spacing`. Tracking for silk-screen
  labels is baked into the string. For short labels only.

Typography: three roles, three families, with automatic fallback.
`Bahnschrift Condensed` (ships with Windows 10/11) for titles and silk-screen
labels, `Segoe UI` for body text, `Cascadia Mono` / `Consolas` for parameter
values — monospaced, so digits do not dance when they change.

### `gp200_ui.py` — components

Canvas-drawn widgets, pure Tkinter. No business logic.

| Component | Role |
|---|---|
| `SignalRack` | The 11 modules and their cord. `set_slots()`, `set_progress(k)`, `start_flow()`, `select(i)`, `selected()` |
| `ModuleInspector` | Every parameter of the selected module. `set_module(mod, pos)` |
| `PresetList` | Dense scrollable list, hover and full-width selection |
| `GlowButton` | Primary action, cyan glow, breathing `set_busy()` state. Exposes `configure(text=, state=)` to stay drop-in compatible with `ttk.Button` |
| `Well` | Rounded recess hosting a `Text` or `Entry` |
| `VMeter` | Segmented bargraph with a target marker (`patch_vol`) |
| `Chip`, `Led`, `Silk`, `GradientStrip` | Value pill, indicator lamp, silk-screen label, gradient band |

Format expected by `SignalRack.set_slots()` — directly derivable from
`decode_prst()`, whose output already has this shape:

```python
[{"slot": "AMP", "model": "Mess2C+ 2", "on": True,
  "params": {"Gain": 65, "Presence": 70, "Volume": 75}}, ...]
```

### What Tkinter cannot do, and how it is worked around

| Missing | Solution |
|---|---|
| Rounded corners | Polygon sampled over quarter-circles (`round_rect_points`) |
| Gradients | Drawn line by line, each line inset by the right amount within corner zones (`corner_inset`) |
| Transparency / glow | Manual blending toward the background colour, layer by layer (`glow_round_rect`) |
| `letter-spacing` | Tracking baked into the string (`sil()`) |
| Rounded `Text` | Recess drawn on a Canvas + `create_window` (`Well`) |
| Styled list rows | `Canvas` instead of `Listbox` (`PresetList`) |

**Accepted limitation**: no anti-aliasing. Rounded corners and glows show slight
diagonal stair-stepping, invisible at 100% zoom. That is Tkinter's ceiling.

### Adaptive rack behaviour

The rack **measures the space it is given** instead of imposing a size. Absolute
priority: all 11 modules on **a single row** — a signal chain that snakes across
two rows is no longer a chain.

1. Compute the card width that fits all 11 modules end to end. Two passes: a
   comfortable gutter first (the cord must be visible), then a tighter one before
   giving up.
2. If the resulting scale drops below 0.46, fall back to multiple serpentine rows,
   with scrolling and height capped at two visible rows.

The rack and the inspector **request exactly their content height**
(`configure(height=...)`, with a 3 px guard against the
`Configure -> resize -> Configure` loop). The Result/Log block, the only widget
with `expand`, absorbs everything left over.

### Tkinter pitfalls documented in the code

* **`self._w` is reserved**: `Misc._w` holds the widget's Tcl path. Internal
  component dimensions are therefore `_cw` / `_ch`.
* **`pack()` ordering**: a container with `expand=True` declared before a footer
  with `side="bottom"` absorbs the whole cavity. The footer must be packed first.
* **`ttk.Panedwindow`** freezes its sash from the size announced at the first
  geometry pass, before the Canvases have drawn their content. Simple stacking
  does not have this flaw — that is what is used.


## Engine files

### `gp200_studio.py` — GUI

Entry point. Handles:
- First-run setup (language selection, API key input)
- The full interface (description input, provider/model selection, structure
  detection, generation and refine modes)
- Chain visualisation, module inspector, navigation through generated presets
- Results display (report, detailed log)
- API usage tracking

Depends on `gp200_agent`, `gp200lib`, `gp200_setlist`, `gp200_i18n`,
`gp200_secrets`, `gp200_theme`, `gp200_ui`.

Design-specific labels live in a local `_DTXT` dictionary with a `DT(key, *args)`
function that follows the current language. Rationale: `gp200_i18n.py` is part of
the engine and stays untouched.

`_build()` must remain **re-entrant**: `_retranslate()` destroys all children and
calls it again. No state may live outside `self.cfg` or variables recreated by
`_build()` — except `self._gen`, the generated preset list, which is explicitly
preserved across a language change.

### `gp200_agent.py` — AI engine

The generation core. Full pipeline:
1. System prompt construction (compact catalog, formatting rules)
2. API call (Gemini, Claude, OpenAI or Perplexity) via `urllib` (stdlib only)
3. JSON response parsing
4. Validation against firmware tables (model names, parameter ranges)
5. Auto-correction loop if the model hallucinates a model name
6. Binary encoding and `.prst` file writing

Also exposes `refine_live()` (live-concert optimisation) and
`estimate_patch_vol()` (preset volume estimation, used by setlist harmonisation).

### `gp200lib.py` — Binary `.prst` format

Reverse-engineered from firmware V1.8.0. Handles:
- **`Tables`**: loads the catalog (models, cabs, parameters, ranges)
- **`encode_prst(spec, tables)`**: JSON dict -> 1224-byte `.prst` file
- **`decode_prst(path, tables)`**: `.prst` file -> readable JSON dict
- Checksum, effects chain order, parameter slots

Key points:
- A model is identified by the pair `(model_id, category)`, not the id alone
- The id space is sparse (not a sequential index)
- 11 module slots: `NR`, `WAH`, `DST`, `AMP`, `CAB`, `MOD`, `DLY`, `RVB`, `EQ`,
  `VOL`, `PRE`

### `gp200_setlist.py` — Setlist harmonisation

`analyze_setlist(paths, tables)` decodes a list of presets and estimates their
volume via `estimate_patch_vol()`. `apply_setlist(entries, output_dir, log=None)`
rewrites the harmonised files into a timestamped folder. Only the `patch_vol`
byte changes, and the checksum is recomputed. No API call.

### `gp200_i18n.py` — Internationalization

Single `STRINGS` dictionary with all engine strings in French, English and
Spanish. Also contains `APP_VERSION`, `PROVIDERS` labels and `T(key, *args)`.

### `gp200_secrets.py` — API key encryption

Uses DPAPI (Windows) to encrypt API keys stored in `config.json`.
On non-Windows platforms, a reversible base64 encoding is used as fallback.
Format: `"dpapi:..."` (encrypted) or `"plain:..."` (encoded).
Legacy plaintext keys are read as-is (backward compatibility).


## Configuration

Copy `config.example.json` to `config.json` and fill in at least one API key:

```json
{
  "provider": "gemini",
  "api_key_gemini": "AIza...",
  "api_key_anthropic": "",
  "api_key_openai": "",
  "api_key_perplexity": "",
  "model": "gemini-3.5-flash",
  "web_search": true,
  "output_dir": "",
  "budget_usd": 6.0
}
```

- **`provider`**: `gemini` (free tier), `anthropic`, `openai`, `perplexity`
- **`web_search`**: web search to identify the real rig (most expensive in tokens)
- **`output_dir`**: output folder for `.prst` files (empty = `Documents\GP200_Presets`)
- **`budget_usd`**: estimated spending cap (Anthropic only)

> The `"theme"` key from earlier versions is ignored: the interface now has a
> single dark palette. Its presence in an existing `config.json` causes no error;
> no migration is needed.


## Running

```bash
# As a script
python gp200_studio.py

# On Windows (double-click)
GP200_Studio.bat

# Selftest (no GUI)
python gp200_studio.py --selftest

# Design mockup only (fake data, no API call)
python design_preview.py
```

`--selftest` must print:
`SELFTEST OK : 216 modeles, 90 cabs, encodage 1224 o`


## Building the .exe

```bash
build_exe.bat
```

Produces `dist/GP200_Studio.exe`. The script:
1. Checks all required files are present, including `gp200_theme.py` and
   `gp200_ui.py`
2. Creates a venv and installs PyInstaller
3. Compiles with `--onefile --windowed`, with `gp200_theme` and `gp200_ui` as
   `--hidden-import`
4. Runs the selftest on the produced exe

No third-party UI dependency is installed: the theme is built in.


## Generation structure

The AI generates between 3 and 9 presets per request, organized in **sections**:
- **Auto** mode: the AI detects the structure (e.g. 3 variants of a sound, or
  clean/crunch/disto for an artist)
- **Forced** mode: the user picks the roles (`clean`, `crunch`, `disto`, `lead`)

Each preset is a JSON dict:
```json
{
  "name": "Blues SRV",
  "modules": {
    "AMP": {"model": "TX Star", "on": true, "params": {"Gain": 65, "Bass": 55}},
    "CAB": {"model": "4x12 Brit G75", "on": true},
    "RVB": {"model": "Spring 63", "on": true, "params": {"Decay": 40}}
  }
}
```

The engine validates every model name and parameter value against the firmware
tables, and automatically corrects hallucinations.

The interface receives this result as a list of `(path, section, variant)` tuples
and builds the navigable sidebar list from it, asking nothing extra of the engine.


## Refine mode

Lets you load an existing `.prst` file, decode it, then request a modification in
plain text (*"more gain, less reverb"*). The AI receives the decoded preset and
produces a modified version. Actual changes (computed by diff on the decoded
files, not claimed by the model) are displayed to the user.

The loaded preset's chain is shown as soon as the file is opened, before any API
call.


## Contributing

The project is free and open. Entry points for contributors:

- **New languages**: add an entry in `LANGS` and translations in `STRINGS`
  (`gp200_i18n.py`), plus the `_DTXT` dictionary in `gp200_studio.py` for
  design-specific labels
- **New providers**: add an entry in `PROVIDERS` (`gp200_agent.py`) and the
  corresponding API call
- **Firmware updates**: if Valeton releases a new firmware with new models,
  extract the tables and add them to `data/`
- **Appearance**: everything goes through `gp200_theme.py`. Changing a colour or
  a spacing value happens in `TOK`, without touching a single component. A light
  mode would mean adding a second palette.
- **New components**: `gp200_ui.py` depends only on `gp200_theme`. Use
  `design_preview.py` to iterate without launching the full application.
