# GP-200 Studio — Documentacion tecnica

## Presentacion

GP-200 Studio es un generador de presets para el **Valeton GP-200**.
El usuario describe un sonido en texto libre (ej. *"crunch bluesy calido estilo
SRV"*), y la aplicacion llama a una API de IA (Gemini, Claude, OpenAI o
Perplexity) para producir archivos `.prst` listos para cargar en la tarjeta SD
del GP-200.

El proyecto esta escrito en **Python 3 / Tkinter**, sin frameworks pesados y
**sin ninguna dependencia externa**: solo biblioteca estandar (`tkinter`,
`urllib`, `json`, `struct`). Puede ejecutarse como script
(`python gp200_studio.py`) o compilarse en un `.exe` autonomo para Windows con
PyInstaller (`build_exe.bat`).


## Estructura del proyecto

```
GP200_Studio/
|
|-- gp200_studio.py          Interfaz grafica Tkinter (punto de entrada)
|-- gp200_theme.py           Sistema de diseno: tokens, tema ttk, escala de pantalla
|-- gp200_ui.py              Componentes graficos dibujados en Canvas
|-- design_preview.py        Maqueta autonoma del diseno (datos ficticios)
|
|-- gp200_agent.py           Motor IA: llamadas API, prompt, validacion, escritura .prst
|-- gp200lib.py              Nucleo binario: codificacion/decodificacion del formato .prst (1224 bytes)
|-- gp200_setlist.py         Armonizacion de volumenes de una setlist
|-- gp200_i18n.py            Traducciones (fr/en/es), version, constantes de interfaz
|-- gp200_secrets.py         Cifrado de claves API via DPAPI (Windows)
|-- gp200_validate.py        Herramienta de validacion de firmware (dev)
|
|-- data/                    Tablas extraidas del firmware GP-200 v1.8.0
|   |-- gp200_models_all.json   216 modelos (amplis, efectos, cabs) con parametros y rangos
|   |-- gp200_cabs.json         90 cabs/IRs
|   |-- gp200_factory_presets.json  128 presets de fabrica (referencia)
|   |-- gp200_descriptions.json     Descripciones de los modelos para el prompt de IA
|   |-- models_amp.json, models_dst.json, ...   Tablas detalladas por categoria
|
|-- template.prst            Preset vacio de referencia (1224 bytes), base de codificacion
|-- config.example.json      Plantilla de configuracion (copiar a config.json)
|-- GP200_Studio.bat         Lanzador Windows (doble clic)
|-- build_exe.bat            Script de compilacion PyInstaller
|
|-- make_descriptions.py     Genera descripciones de los modelos (dev)
|-- patch_data.py            Parches sobre las tablas firmware (dev)
|-- bump_version.py          Incrementa APP_VERSION antes de compilar (dev)
|-- xml_diff.py              Compara dos exportaciones XML del GP-200 (dev)
|
|-- CHANGELOG.md             Historial de cambios
|-- .gitignore               Ignora config.json, .venv/, build/, dist/
```

### Separacion estricta motor / presentacion

La capa grafica (`gp200_studio.py`, `gp200_theme.py`, `gp200_ui.py`) y el motor
(`gp200_agent.py`, `gp200lib.py`, `gp200_setlist.py`, `gp200_secrets.py`) son
independientes:

* `gp200_theme.py` y `gp200_ui.py` **no importan nada del motor**. No saben lo
  que es un `.prst`. Reciben diccionarios y emiten callbacks.
* El motor no importa nada de la capa grafica.

Consecuencia practica: se puede rehacer la interfaz por completo sin riesgo de
regresion en la generacion, y `design_preview.py` se ejecuta sin clave API, sin
red y sin poder escribir ningun archivo.


## Interfaz grafica

### `gp200_theme.py` — sistema de diseno

Sin logica de negocio. Expone:

* **`TOK`**: tokens de diseno. Colores (fondo, tintas, filetes, acento cian,
  estados) y geometria (radios, espaciados, tamanos de tarjeta, ancho de la
  columna lateral).
* **`CAT`** / **`SLOT_CAT`**: los 11 modulos agrupados en tres familias. El color
  no es decorativo, indica donde estas en la cadena de senal:

  | Familia | Modulos | Papel |
  |---|---|---|
  | `GEN` — azul glaciar | `PRE`, `DST`, `AMP` | crea el sonido |
  | `CAB` — verde | `NR`, `CAB`, `EQ` | lo moldea |
  | `FX` — magenta | `WAH`, `MOD`, `DLY`, `RVB`, `VOL` | lo colorea |

* **`apply_theme(root, scale=None)`**: recablea por completo el tema ttk sobre la
  paleta. Basado en `clam`, el unico tema ttk totalmente recoloreable en los tres
  sistemas. Devuelve el diccionario `FONT`.
* **`compute_scale(root)`** / **`scale_tokens(s)`** / **`UI_SCALE`**: factor de
  escala deducido de la resolucion de pantalla, limitado a 0,85 - 1,30. El
  escalado parte siempre de una copia de referencia de los tokens, nunca del
  resultado anterior: dos llamadas a `apply_theme()` no componen sus factores.
* **Utilidades de color**: `mix`, `lighten`, `darken`, `ramp`, `luma`.
* **Geometria**: `round_rect_points()` muestrea los cuatro cuartos de circulo
  (radio exacto, a diferencia del truco `smooth=True` que produce una spline
  aproximada); `corner_inset()` da el retranqueo horizontal a una altura dada
  dentro de una esquina, lo que permite recortar un degradado linea a linea sobre
  una forma redondeada.
* **`sil(texto)`**: Tkinter no tiene `letter-spacing`. El interletraje de las
  etiquetas serigrafiadas se inserta en la cadena. Solo para etiquetas cortas.

Tipografia: tres papeles, tres familias con recurso automatico.
`Bahnschrift Condensed` (incluida en Windows 10/11) para titulos y serigrafia,
`Segoe UI` para el texto corriente, `Cascadia Mono` / `Consolas` para los valores
de parametros — ancho fijo, para que las cifras no bailen al cambiar.

### `gp200_ui.py` — componentes

Widgets dibujados en Canvas, Tkinter puro. Sin logica de negocio.

| Componente | Papel |
|---|---|
| `SignalRack` | Los 11 modulos y su cable. `set_slots()`, `set_progress(k)`, `start_flow()`, `select(i)`, `selected()` |
| `ModuleInspector` | Todos los parametros del modulo elegido. `set_module(mod, pos)` |
| `PresetList` | Lista densa con scroll, hover y seleccion a todo lo ancho |
| `GlowButton` | Accion primaria, halo cian, estado `set_busy()` pulsante. Expone `configure(text=, state=)` para seguir siendo compatible con `ttk.Button` |
| `Well` | Hueco con esquinas redondeadas que aloja un `Text` o un `Entry` |
| `VMeter` | Bargraph por segmentos con marca de objetivo (`patch_vol`) |
| `Chip`, `Led`, `Silk`, `GradientStrip` | Pastilla de valor, testigo luminoso, etiqueta serigrafiada, banda degradada |

Formato esperado por `SignalRack.set_slots()` — derivable directamente de
`decode_prst()`, cuya salida ya tiene esta forma:

```python
[{"slot": "AMP", "model": "Mess2C+ 2", "on": True,
  "params": {"Gain": 65, "Presence": 70, "Volume": 75}}, ...]
```

### Lo que Tkinter no sabe hacer, y como se resuelve

| Carencia | Solucion |
|---|---|
| Esquinas redondeadas | Poligono muestreado sobre cuartos de circulo (`round_rect_points`) |
| Degradados | Trazado linea a linea, cada linea retranqueada lo justo en la zona de las esquinas (`corner_inset`) |
| Transparencia / halo | Mezcla manual hacia el color de fondo, capa a capa (`glow_round_rect`) |
| `letter-spacing` | Interletraje insertado en la cadena (`sil()`) |
| `Text` redondeado | Hueco dibujado en Canvas + `create_window` (`Well`) |
| Filas de lista con estilo | `Canvas` en lugar de `Listbox` (`PresetList`) |

**Limitacion aceptada**: sin antialiasing. Los redondeos y halos presentan un
ligero escalonado en diagonal, invisible al 100 % de zoom. Es el techo de Tkinter.

### Comportamiento adaptativo del rack

El rack **mide el espacio que se le da** en lugar de imponerse un tamano.
Prioridad absoluta: los 11 modulos en **una sola linea** — una cadena de senal que
serpentea en dos filas ya no es una cadena.

1. Se calcula el ancho de tarjeta que hace caber los 11 modulos de extremo a
   extremo. Dos pasadas: primero una separacion comoda (hay que ver el cable),
   luego mas apretada antes de renunciar.
2. Si la escala resultante baja de 0,46, se recurre a varias filas en serpentina,
   con scroll y altura limitada a dos filas visibles.

El rack y el inspector **piden exactamente la altura de su contenido**
(`configure(height=...)`, con una guarda de 3 px contra el bucle
`Configure -> resize -> Configure`). El bloque Resultado/Registro, unico con
`expand`, absorbe todo lo restante.

### Trampas de Tkinter documentadas en el codigo

* **`self._w` esta reservado**: `Misc._w` contiene la ruta Tcl del widget. Las
  dimensiones internas de los componentes son por tanto `_cw` / `_ch`.
* **Orden de `pack()`**: un contenedor con `expand=True` declarado antes de un pie
  con `side="bottom"` absorbe toda la cavidad. El pie debe empaquetarse primero.
* **`ttk.Panedwindow`** congela su divisor segun el tamano anunciado en el primer
  calculo de geometria, antes de que los Canvas hayan dibujado su contenido. Un
  apilado simple no tiene ese defecto — es lo que se usa.


## Archivos del motor

### `gp200_studio.py` — Interfaz grafica

Punto de entrada. Gestiona:
- Primera ejecucion (seleccion de idioma, introduccion de claves API)
- La interfaz completa (descripcion, seleccion de proveedor/modelo, deteccion de
  estructura, modo generacion y modo refinamiento)
- Visualizacion de la cadena, inspector de modulo, navegacion por los presets
  generados
- Visualizacion de resultados (informe, registro detallado)
- Seguimiento de consumo API

Depende de `gp200_agent`, `gp200lib`, `gp200_setlist`, `gp200_i18n`,
`gp200_secrets`, `gp200_theme`, `gp200_ui`.

Las etiquetas propias del diseno viven en un diccionario `_DTXT` local, con una
funcion `DT(key, *args)` que sigue el idioma actual. Motivo: `gp200_i18n.py`
forma parte del motor y permanece intacto.

`_build()` debe seguir siendo **reentrante**: `_retranslate()` destruye todos los
hijos y vuelve a llamarlo. Ningun estado puede vivir fuera de `self.cfg` o de
variables recreadas por `_build()` — salvo `self._gen`, la lista de presets
generados, preservada explicitamente al cambiar de idioma.

### `gp200_agent.py` — Motor IA

El nucleo de la generacion. Cadena completa:
1. Construccion del prompt de sistema (catalogo compacto, reglas de formato)
2. Llamada API (Gemini, Claude, OpenAI o Perplexity) via `urllib` (stdlib)
3. Parsing de la respuesta JSON
4. Validacion contra las tablas del firmware (nombres de modelos, rangos)
5. Bucle de auto-correccion si el modelo alucina un nombre de modelo
6. Codificacion binaria y escritura de archivos `.prst`

Expone tambien `refine_live()` (optimizacion para concierto) y
`estimate_patch_vol()` (estimacion del volumen de un preset, usada por la
armonizacion de setlist).

### `gp200lib.py` — Formato binario `.prst`

Obtenido por ingenieria inversa del firmware V1.8.0. Gestiona:
- **`Tables`**: carga el catalogo (modelos, cabs, parametros, rangos)
- **`encode_prst(spec, tables)`**: dict JSON -> archivo `.prst` de 1224 bytes
- **`decode_prst(path, tables)`**: archivo `.prst` -> dict JSON legible
- Checksum, cadena de efectos (chain_order), slots de parametros

Puntos clave:
- Un modelo se identifica por el par `(model_id, category)`, no solo por el id
- El espacio de ids es hueco (no es un indice secuencial)
- 11 slots de modulos: `NR`, `WAH`, `DST`, `AMP`, `CAB`, `MOD`, `DLY`, `RVB`,
  `EQ`, `VOL`, `PRE`

### `gp200_setlist.py` — Armonizacion de setlist

`analyze_setlist(paths, tables)` decodifica una lista de presets y estima su
volumen via `estimate_patch_vol()`. `apply_setlist(entries, output_dir, log=None)`
reescribe los archivos armonizados en una carpeta con marca de tiempo. Solo cambia
el byte `patch_vol`, y el checksum se recalcula. Ninguna llamada API.

### `gp200_i18n.py` — Internacionalizacion

Diccionario unico `STRINGS` con todas las cadenas del motor en frances, ingles y
espanol. Contiene tambien `APP_VERSION`, las etiquetas `PROVIDERS` y la funcion
`T(key, *args)`.

### `gp200_secrets.py` — Cifrado de claves API

Usa DPAPI (Windows) para cifrar las claves API en `config.json`.
En plataformas no-Windows, se usa una codificacion base64 reversible como
alternativa. Formato: `"dpapi:..."` (cifrado) o `"plain:..."` (codificado).
Las claves antiguas en texto plano se leen tal cual (retrocompatibilidad).


## Configuracion

Copiar `config.example.json` a `config.json` y completar al menos una clave API:

```json
{
  "provider": "gemini",
  "api_key_gemini": "AIza...",
  "api_key_anthropic": "",
  "api_key_openai": "",
  "api_key_perplexity": "",
  "model": "gemini-3.5-flash",
  "web_search": true,
  "output_dir": "",
  "budget_usd": 6.0
}
```

- **`provider`**: `gemini` (gratuito), `anthropic`, `openai`, `perplexity`
- **`web_search`**: busqueda web para identificar el rig real (lo mas costoso en tokens)
- **`output_dir`**: carpeta de salida de los `.prst` (vacio = `Documents\GP200_Presets`)
- **`budget_usd`**: tope de gasto estimado (solo Anthropic)

> La clave `"theme"` de versiones anteriores se ignora: la interfaz solo tiene ya
> una paleta oscura. Su presencia en un `config.json` existente no provoca ningun
> error; no hace falta migracion.


## Ejecucion

```bash
# Como script
python gp200_studio.py

# En Windows (doble clic)
GP200_Studio.bat

# Selftest (sin interfaz)
python gp200_studio.py --selftest

# Solo la maqueta del diseno (datos ficticios, sin llamada API)
python design_preview.py
```

`--selftest` debe responder:
`SELFTEST OK : 216 modeles, 90 cabs, encodage 1224 o`


## Compilacion a .exe

```bash
build_exe.bat
```

Produce `dist/GP200_Studio.exe`. El script:
1. Verifica que estan todos los archivos requeridos, incluidos `gp200_theme.py`
   y `gp200_ui.py`
2. Crea un venv e instala PyInstaller
3. Compila con `--onefile --windowed`, con `gp200_theme` y `gp200_ui` como
   `--hidden-import`
4. Ejecuta el selftest sobre el exe producido

No se instala ninguna dependencia grafica de terceros: el tema esta integrado.


## Estructura de la generacion

La IA genera entre 3 y 9 presets por solicitud, organizados en **secciones**:
- Modo **automatico**: la IA detecta la estructura (ej. 3 variantes de un sonido,
  o clean/crunch/disto para un artista)
- Modo **forzado**: el usuario elige los roles (`clean`, `crunch`, `disto`, `lead`)

Cada preset es un dict JSON:
```json
{
  "name": "Blues SRV",
  "modules": {
    "AMP": {"model": "TX Star", "on": true, "params": {"Gain": 65, "Bass": 55}},
    "CAB": {"model": "4x12 Brit G75", "on": true},
    "RVB": {"model": "Spring 63", "on": true, "params": {"Decay": 40}}
  }
}
```

El motor valida cada nombre de modelo y cada valor de parametro contra las tablas
del firmware, y corrige automaticamente las alucinaciones.

La interfaz recibe este resultado como una lista de `(ruta, seccion, variante)` y
construye a partir de ella la lista navegable de la columna izquierda, sin pedirle
nada mas al motor.


## Modo refinamiento (refine)

Permite cargar un archivo `.prst` existente, decodificarlo y solicitar una
modificacion en texto libre (*"mas ganancia, menos reverb"*). La IA recibe el
preset decodificado y produce una version modificada. Los cambios reales
(calculados por diff sobre los archivos decodificados, no declarados por el
modelo) se muestran al usuario.

La cadena del preset cargado se muestra nada mas abrir el archivo, antes de
cualquier llamada API.


## Contribuir

El proyecto es libre y abierto. Puntos de entrada para contribuir:

- **Nuevos idiomas**: anadir una entrada en `LANGS` y las traducciones en
  `STRINGS` (`gp200_i18n.py`), mas el diccionario `_DTXT` de `gp200_studio.py`
  para las etiquetas propias del diseno
- **Nuevos proveedores**: anadir una entrada en `PROVIDERS` (`gp200_agent.py`) y
  la llamada API correspondiente
- **Actualizaciones de firmware**: si Valeton publica un nuevo firmware con
  nuevos modelos, extraer las tablas y anadirlas en `data/`
- **Apariencia**: todo pasa por `gp200_theme.py`. Cambiar un color o un espaciado
  se hace en `TOK`, sin tocar ni un solo componente. Un modo claro consistiria en
  anadir una segunda paleta.
- **Nuevos componentes**: `gp200_ui.py` solo depende de `gp200_theme`. Usar
  `design_preview.py` para iterar sin lanzar la aplicacion completa.
