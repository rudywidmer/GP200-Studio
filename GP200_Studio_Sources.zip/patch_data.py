#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Aligne data/gp200_models_all.json sur algorithm.xml (source Valeton).

Ne touche qu'aux divergences DEMONTREES par le XML :
  - 5 noms de modeles
  - 6 noms de parametres
  - ajout des 10 SnapTone (cat 15), absents de l'extraction firmware

Ne touche a RIEN d'autre : les 200 modeles au parametrage exact, les slots
(y compris la permutation Ping Pong) et les bornes sont confirmes par le XML.

Usage : python patch_data.py algorithm.xml
"""
import json, shutil, sys, os

XML_PARSED = "xml_parsed.json"          # produit par xml_diff.py
SRC = "data/gp200_models_all.json"

# ------------------------------------------------------- correctifs demontres
NOMS_MODELES = {
    (1, 77): "Harmonizer 1",     # BLOQUANT : _norm n'absorbe pas
    (1, 78): "Harmonizer 2",     # BLOQUANT
    (7, 59): "Mess2C+ 3",        # cosmetique
    (10, 3): "DARK LUX",         # cosmetique (cab)
    (10, 4): "DARK VIT",         # cosmetique (cab)
}
NOMS_PARAMS = {
    (1, 77): {"Smooth": "Smooth Mode"},
    (1, 78): {"Smooth": "Smooth Mode"},
    (4, 24): {"Sense": "Sens"},
    (11, 3): {"A Sync": "Sync A", "B Sync": "Sync B"},
    (11, 33): {"Wow & Flutter": "Wow &"},
}

def main():
    if not os.path.exists(XML_PARSED):
        sys.exit("Lance d'abord : python xml_diff.py algorithm.xml")
    xml = json.load(open(XML_PARSED, encoding="utf-8"))
    models = json.load(open(SRC, encoding="utf-8"))
    shutil.copy(SRC, SRC + ".bak")

    n_nom = n_par = 0
    for m in models:
        k = (m["cat"], m["id"])
        if k in NOMS_MODELES and m["name"] != NOMS_MODELES[k]:
            print("  nom   cat%-2d id=%-4d %-16s -> %s" % (k[0], k[1], m["name"], NOMS_MODELES[k]))
            m["name"] = NOMS_MODELES[k]; n_nom += 1
        for p in m.get("params", []):
            ren = NOMS_PARAMS.get(k, {})
            if p["name"] in ren:
                print("  param cat%-2d id=%-4d %-16s %-14s -> %s"
                      % (k[0], k[1], m["name"], p["name"], ren[p["name"]]))
                p["name"] = ren[p["name"]]; n_par += 1

    # ------------------------------------------------- SnapTone (cat 15)
    have = {(m["cat"], m["id"]) for m in models}
    n_snap = 0
    for key, v in sorted(xml.items(), key=lambda kv: [int(x) for x in kv[0].split(",")]):
        cat, mid = (int(x) for x in key.split(","))
        if cat != 15 or (cat, mid) in have:
            continue
        params = []
        for i, p in enumerate(v["params"]):
            params.append({
                "name": p["name"], "slot": int(p["ID"]), "ui_order": i,
                "min": p["min"], "max": p["max"], "step": 1.0,
                "default": p["default"], "unit_code": 0, "type_code": 21,
            })
        models.append({
            "id": mid, "cat": 15, "catname": "SNAPTONE", "name": v["name"],
            "category_label": "SnapTone", "n_params": len(params),
            "params": params, "defcab": None, "fw_offset": None,
            "source": "algorithm.xml",   # PAS extrait du firmware : tracabilite
            "catalogs": v["catalogs"],
        })
        n_snap += 1
        print("  +     cat15 id=%-4d SnapTone (%s) %d params"
              % (mid, ",".join(v["catalogs"]), len(params)))

    json.dump(models, open(SRC, "w", encoding="utf-8"), indent=1,
              ensure_ascii=False)
    print("\n%d noms de modeles, %d noms de parametres, %d SnapTone ajoutes"
          % (n_nom, n_par, n_snap))
    print("total : %d modeles  (sauvegarde : %s.bak)" % (len(models), SRC))
    print("""
RESTE A FAIRE A LA MAIN dans gp200lib.py :

  1) SLOT_ACCEPTS — ouvrir SnapTone (confirme par les catalogues du XML) :
        "DST": [3, 0, 15],
        "AMP": [7, 8, 15],

  2) decode_prst — le champ `flags` est l'octet HAUT de l'id, pas un extra.
     flags 0x10 = User IR. Actuellement un User IR se decode en cab d'usine :
        - c = tables.cab(mid) or tables.cab(mid, user=True)
        + c = tables.cab(mid, user=bool(flags & 0x10))

  3) encode_prst — flags est ecrit en dur a 0, donc aucun User IR possible :
        - struct.pack_into("<HBB", payload, 0, mid, 0, cat)
        + struct.pack_into("<HBB", payload, 0, mid, 0x10 if user_ir else 0, cat)
     et Tables.find("CAB", ...) doit pouvoir viser _cab_by_name ET cab_user.
""")

if __name__ == "__main__":
    main()
