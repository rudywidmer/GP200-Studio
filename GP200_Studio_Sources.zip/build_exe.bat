@echo off
setlocal enabledelayedexpansion
REM ============================================================
REM  GP-200 Studio - compilation Windows
REM  A lancer depuis un terminal NON-administrateur.
REM ============================================================
cd /d "%~dp0"
echo.
echo   Dossier de travail : %CD%
echo.

net session >nul 2>&1
if %errorlevel%==0 (
  echo   [!] Tu es en ADMINISTRATEUR. PyInstaller le deconseille et le bloquera
  echo       en version 7.0. Ferme et relance en session normale.
  echo.
  choice /c ON /n /m "  Continuer quand meme ? [O/N] "
  if errorlevel 2 exit /b 1
  echo.
)

echo [1/6] Verification des fichiers...
set MISSING=0
for %%F in (gp200_studio.py gp200_agent.py gp200lib.py gp200_i18n.py gp200_secrets.py gp200_setlist.py gp200_theme.py gp200_ui.py template.prst) do (
  if exist "%%F" ( echo        OK   %%F ) else ( echo        !!   %%F  MANQUANT & set MISSING=1 )
)
if exist "data\" (
  set /a NJSON=0
  for %%F in (data\*.json) do set /a NJSON+=1
  echo        OK   data\  ^(!NJSON! fichiers .json^)
  if !NJSON! LSS 15 ( echo        !!   data\ incomplet : !NJSON! trouves, 15 attendus & set MISSING=1 )
) else ( echo        !!   data\  MANQUANT & set MISSING=1 )
for %%F in (gp200_models_all.json gp200_cabs.json gp200_factory_presets.json) do (
  if not exist "data\%%F" ( echo        !!   data\%%F  MANQUANT & set MISSING=1 )
)
if !MISSING!==1 (
  echo.
  echo   ============================================================
  echo    FICHIERS MANQUANTS.
  echo.
  echo    Extrais TOUT le contenu de GP200_Studio.zip dans :
  echo      %CD%
  echo.
  echo    Le .bat, les .py, template.prst et le dossier data\
  echo    doivent etre AU MEME NIVEAU. Pas de sous-dossier GP200_Studio\.
  echo   ============================================================
  echo.
  pause & exit /b 1
)

echo.
echo [2/6] Python...
where python >nul 2>&1 || (
  echo        !! Python introuvable dans le PATH.
  echo           https://www.python.org/downloads/  ^(cocher "Add python.exe to PATH"^)
  pause & exit /b 1
)
for /f "tokens=*" %%V in ('python --version 2^>^&1') do echo        %%V
python -c "import tkinter" 2>nul || (
  echo        !! Tkinter absent. Reinstalle Python en cochant "tcl/tk and IDLE".
  pause & exit /b 1
)
echo        Tkinter OK

echo.
echo [3/6] Environnement virtuel...
if not exist ".venv\Scripts\activate.bat" (
  python -m venv .venv || (echo        !! Echec creation venv & pause & exit /b 1)
  echo        cree
) else ( echo        reutilise )
call ".venv\Scripts\activate.bat"

echo.
echo [4/6] PyInstaller...
python -m pip install --quiet --upgrade pip pyinstaller || (
  echo        !! Echec pip. Proxy d'entreprise ? Definis HTTPS_PROXY.
  pause & exit /b 1
)
for /f "tokens=*" %%V in ('python -m PyInstaller --version 2^>^&1') do echo        version %%V

echo.
echo [5/6] Compilation ^(quelques minutes^)...
if exist "GP200_Studio.spec" del /q "GP200_Studio.spec"
if exist "build\" rmdir /s /q "build"
python -m PyInstaller --noconfirm --clean --onefile --windowed ^
  --name GP200_Studio ^
  --paths "." ^
  --hidden-import gp200lib ^
  --hidden-import gp200_agent ^
  --hidden-import gp200_i18n ^
  --hidden-import gp200_secrets ^
  --hidden-import gp200_setlist ^
  --hidden-import gp200_theme ^
  --hidden-import gp200_ui ^
  --add-data "data;data" ^
  --add-data "template.prst;." ^
  gp200_studio.py
if not exist "dist\GP200_Studio.exe" (
  echo.
  echo        !! Compilation echouee. Lis les lignes ERROR ci-dessus.
  pause & exit /b 1
)

REM ---------- 6. verification de l'exe produit ----------
echo.
echo [6/6] Verification de l'exe...
if exist "dist\selftest.log" del /q "dist\selftest.log"
"dist\GP200_Studio.exe" --selftest
if errorlevel 1 (
  echo.
  echo        !! L'exe est incomplet.
  if exist "dist\selftest.log" ( echo. & type "dist\selftest.log" )
  echo.
  echo        Signale ce message : le bundle ne contient pas tout.
  pause & exit /b 1
)
if exist "dist\selftest.log" ( type "dist\selftest.log" & del /q "dist\selftest.log" )
echo        exe verifie : tables, template et encodage OK

if not exist "dist\config.json" copy "config.example.json" "dist\config.json" >nul
echo.
echo   ============================================================
echo    OK  --^>  dist\GP200_Studio.exe
echo.
echo    DERNIERE ETAPE : ouvre dist\config.json et colle ta cle API.
echo    L'exe et config.json doivent rester dans le meme dossier.
echo   ============================================================
echo.
pause